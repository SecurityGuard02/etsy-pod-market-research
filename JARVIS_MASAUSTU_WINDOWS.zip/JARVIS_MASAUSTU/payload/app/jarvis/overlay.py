"""Native Windows transparent orb, animated from the supplied reference video.

There is no browser window or GUI framework in this process. Pillow decodes the
bundled video-derived WebP; UpdateLayeredWindow composites premultiplied pixels
onto the real desktop. The local server owns voice, automation and approval.
This view can request only a small fixed set of authenticated loopback actions.

Pure image/protocol helpers are importable on other operating systems. The
actual layered window intentionally requires an interactive Windows desktop.
"""
from __future__ import annotations

import argparse
from bisect import bisect_right
from dataclasses import dataclass
import hashlib
import json
import logging
from logging.handlers import RotatingFileHandler
import os
from pathlib import Path
import queue
import sys
import threading
import time
from urllib.request import ProxyHandler, Request, build_opener

from PIL import Image, ImageChops, ImageDraw, ImageFont, ImageOps, ImageSequence

from .desktop import (DesktopError, InstanceLock, NoRedirect, Paths, application_paths,
                      open_window, read_state, validate_browser_url)


LOGGER = logging.getLogger("jarvis.overlay")
ASSET = Path(__file__).resolve().parent / "assets" / "jarvis_orb.webp"
ORB_SIZE = (296, 280)
CANVAS_SIZE = (316, 346)
STATES = frozenset({"idle", "listening", "working", "speaking", "error"})
ACTIONS = frozenset({"listen", "mute", "settings", "stop", "close"})
BUTTONS = (("listen", (24, 310, 106, 338)),
           ("settings", (115, 310, 197, 338)),
           ("stop", (206, 310, 292, 338)))
STATE_TEXT = {"idle": "Hazır · Dinlemek için tıklayın", "listening": "Dinliyorum",
              "working": "Çalışıyorum", "speaking": "Konuşuyorum",
              "error": "Hata · Ayarları kontrol edin"}


@dataclass(frozen=True)
class HudSnapshot:
    state: str = "idle"
    message: str = ""
    mic_enabled: bool = False
    busy: bool = False

    @classmethod
    def from_response(cls, response: dict) -> "HudSnapshot":
        if (not isinstance(response, dict) or not isinstance(response.get("state"), str)
                or response["state"] not in STATES):
            raise ValueError("Invalid local assistant state")
        message = response.get("message", "")
        if not isinstance(message, str):
            raise ValueError("Invalid local assistant message")
        # A server diagnostic is data, never markup or a command.
        message = " ".join(message.split())[:300]
        return cls(response["state"], message,
                   response.get("mic_enabled") is True, response.get("busy") is True)


def remove_black_background(image: Image.Image) -> Image.Image:
    """Recover translucent light from an opaque video frame shot on black.

    Unpremultiplying against max(R,G,B) preserves the original glow when the
    result is placed on black and leaves black completely transparent. Assets
    already carrying alpha are left untouched, avoiding double keying.
    """
    rgba = image.convert("RGBA")
    if rgba.getchannel("A").getextrema() != (255, 255):
        return rgba
    source = rgba.tobytes()
    result = bytearray(len(source))
    for index in range(0, len(source), 4):
        r, g, b = source[index:index + 3]
        alpha = max(r, g, b)
        if alpha:
            result[index] = min(255, round(r * 255 / alpha))
            result[index + 1] = min(255, round(g * 255 / alpha))
            result[index + 2] = min(255, round(b * 255 / alpha))
            result[index + 3] = alpha
    return Image.frombytes("RGBA", rgba.size, bytes(result))


def tint_frame(image: Image.Image, state: str) -> Image.Image:
    """Keep the source orange for idle/work and preserve alpha for every tint."""
    if state not in STATES:
        raise ValueError("Unknown orb state")
    rgba = image.convert("RGBA")
    color = {"listening": (42, 166, 255), "error": (255, 46, 61),
             "speaking": (255, 210, 99)}.get(state)
    if color is None:
        return rgba.copy()
    red, green, blue, alpha = rgba.split()
    value = ImageChops.lighter(ImageChops.lighter(red, green), blue)
    colored = ImageOps.colorize(value, black=(0, 0, 0), white=color).convert("RGBA")
    colored.putalpha(alpha)
    return colored


def premultiplied_bgra(image: Image.Image) -> bytes:
    """Windows AC_SRC_ALPHA requires premultiplied (not straight) BGRA."""
    red, green, blue, alpha = image.convert("RGBA").split()
    premultiplied = Image.merge("RGBA", (ImageChops.multiply(red, alpha),
                                         ImageChops.multiply(green, alpha),
                                         ImageChops.multiply(blue, alpha), alpha))
    return premultiplied.tobytes("raw", "BGRA")


class AnimationClip:
    def __init__(self, asset: Path = ASSET):
        if not asset.is_file():
            raise DesktopError("JARVIS video animasyonu bulunamadı. Kurulum paketini yeniden açın.")
        if asset.stat().st_size > 40_000_000:
            raise DesktopError("JARVIS video animasyonu beklenen boyutu aşıyor.")
        self.frames: list[Image.Image] = []
        self.ends: list[int] = []
        with Image.open(asset) as source:
            if source.width > 1024 or source.height > 1024 or source.n_frames > 600:
                raise DesktopError("JARVIS video animasyonunun boyutları desteklenmiyor.")
            for frame in ImageSequence.Iterator(source):
                rgba = remove_black_background(frame)
                if rgba.size != ORB_SIZE:
                    fitted = ImageOps.contain(rgba, ORB_SIZE, Image.Resampling.LANCZOS)
                    rgba = Image.new("RGBA", ORB_SIZE)
                    rgba.alpha_composite(fitted, ((ORB_SIZE[0] - fitted.width) // 2,
                                                  (ORB_SIZE[1] - fitted.height) // 2))
                self.frames.append(rgba)
                duration = max(16, min(2000, int(frame.info.get("duration", 33))))
                self.ends.append((self.ends[-1] if self.ends else 0) + duration)
        if not self.frames:
            raise DesktopError("JARVIS video animasyonu boş.")

    def frame_at(self, elapsed_ms: float) -> Image.Image:
        index = bisect_right(self.ends, max(0, elapsed_ms) % self.ends[-1])
        return self.frames[min(index, len(self.frames) - 1)]


def hud_request(state: dict, action: str | None = None, timeout: float = 1.0) -> dict:
    """Only the authenticated, non-proxied local HUD protocol is available."""
    port, token = state.get("port"), state.get("control_token")
    if type(port) is not int or not 1 <= port <= 65535 or not isinstance(token, str) or len(token) < 32:
        raise ValueError("Invalid local runtime credentials")
    if action is not None and (not isinstance(action, str) or action not in ACTIONS):
        raise ValueError("Unsupported HUD action")
    if action == "close":
        path, method, data = "/desktop/stop", "POST", b"{}"
    elif action is not None:
        path, method = "/desktop/hud/action", "POST"
        data = json.dumps({"action": action}, separators=(",", ":")).encode("utf-8")
    else:
        path, method, data = "/desktop/hud/state", "GET", None
    opener = build_opener(ProxyHandler({}), NoRedirect())
    request = Request(f"http://127.0.0.1:{port}{path}", data=data, method=method,
                      headers={"X-Desktop-Token": token, "Content-Type": "application/json"})
    with opener.open(request, timeout=timeout) as response:
        raw = response.read(16385)
    if len(raw) > 16384:
        raise ValueError("Oversized local HUD response")
    result = json.loads(raw)
    if not isinstance(result, dict):
        raise ValueError("Invalid local HUD response")
    return result


class HudConnection:
    """HTTP stays on a worker: dragging and emergency controls stay responsive."""
    def __init__(self, paths: Paths):
        self.paths = paths
        self._snapshot = HudSnapshot("working", "JARVIS'e bağlanılıyor")
        self._lock = threading.Lock()
        self._commands: queue.Queue[str] = queue.Queue(maxsize=8)
        self.stopping = threading.Event()
        self.close_window = threading.Event()
        self._thread = threading.Thread(target=self._run, name="jarvis-orb-control", daemon=True)
        self._connected = False
        self._instance: str | None = None

    def start(self):
        self._thread.start()

    def snapshot(self) -> HudSnapshot:
        with self._lock:
            return self._snapshot

    def _set(self, snapshot: HudSnapshot):
        with self._lock:
            self._snapshot = snapshot

    def _discard_commands(self):
        try:
            while True:
                self._commands.get_nowait()
        except queue.Empty:
            pass

    def action(self, action: str):
        if not isinstance(action, str) or action not in ACTIONS:
            raise ValueError("Unsupported HUD action")
        # Explicit emergency/exit commands take priority over queued clicks.
        if action in {"stop", "close"}:
            self._discard_commands()
        try:
            self._commands.put_nowait(action)
        except queue.Full:
            self._set(HudSnapshot("error", "İşlem sürüyor; bir an bekleyin"))

    def _perform(self, state: dict, action: str):
        result = hud_request(state, action)
        if action == "settings":
            # Never open a URL provided by research material or arbitrary state.
            open_window(validate_browser_url(result.get("url", ""), state))
        if action == "close":
            self.close_window.set()

    def _run(self):
        missing_since = None
        while not self.stopping.is_set():
            state = read_state(self.paths)
            if not state:
                missing_since = missing_since or time.monotonic()
                if self._connected and time.monotonic() - missing_since >= 2.0:
                    self.close_window.set()
                    return
                self._set(HudSnapshot("error", "Yerel JARVIS bağlantısı bekleniyor"))
                self.stopping.wait(0.2)
                continue
            missing_since = None
            replaced = self._instance is not None and self._instance != state["instance"]
            if replaced:
                # Reuse the existing view after a same-profile server restart,
                # but never submit clicks pending against the previous server.
                self._discard_commands()
                self._connected = False
                self._set(HudSnapshot("working", "JARVIS'e yeniden bağlanılıyor"))
            self._instance = state["instance"]
            try:
                action = None
                if not replaced:
                    try:
                        action = self._commands.get_nowait()
                    except queue.Empty:
                        pass
                if action:
                    self._perform(state, action)
                    if self.close_window.is_set():
                        return
                self._set(HudSnapshot.from_response(hud_request(state)))
                self._connected = True
            except (OSError, ValueError, DesktopError):
                # No credentials, URLs, screenshots or API response bodies in logs.
                self._set(HudSnapshot("error", "Bağlantı veya işlem hatası · Ayarlar"))
            self.stopping.wait(0.2)


def _font(size: int):
    candidates = [Path(os.getenv("WINDIR", "C:/Windows")) / "Fonts" / "segoeui.ttf",
                  Path("DejaVuSans.ttf")]
    for candidate in candidates:
        try:
            return ImageFont.truetype(str(candidate), size)
        except OSError:
            pass
    return ImageFont.load_default(size=size)


class OrbRenderer:
    def __init__(self, clip: AnimationClip):
        self.clip = clip
        self.font = _font(12)
        self.button_font = _font(12)

    def render(self, snapshot: HudSnapshot, elapsed_ms: float, scale: float = 1.0,
               show_controls: bool = True) -> Image.Image:
        canvas = Image.new("RGBA", CANVAS_SIZE)
        image = tint_frame(self.clip.frame_at(elapsed_ms), snapshot.state)
        canvas.alpha_composite(image, (10, 0))
        if not show_controls:
            if scale != 1.0:
                canvas = canvas.resize((round(CANVAS_SIZE[0] * scale), round(CANVAS_SIZE[1] * scale)),
                                       Image.Resampling.LANCZOS)
            return canvas
        draw = ImageDraw.Draw(canvas)
        text = snapshot.message or STATE_TEXT[snapshot.state]
        while text and draw.textbbox((0, 0), text, font=self.font)[2] > 276:
            text = text[:-2].rstrip("… ") + "…"
        text_box = draw.textbbox((0, 0), text, font=self.font)
        width = text_box[2] - text_box[0]
        left = (CANVAS_SIZE[0] - width) / 2
        draw.rounded_rectangle((left - 8, 280, left + width + 8, 302), radius=8,
                               fill=(10, 16, 23, 188))
        color = (255, 99, 109, 255) if snapshot.state == "error" else (231, 235, 242, 255)
        draw.text((left, 282 - text_box[1]), text, font=self.font, fill=color)
        for action, box in BUTTONS:
            label = {"listen": "Sustur" if snapshot.mic_enabled else "Dinle",
                     "settings": "Ayarlar", "stop": "Acil dur"}[action]
            active = action == "listen" and snapshot.mic_enabled
            fill = (20, 88, 139, 225) if active else (15, 23, 33, 218)
            outline = (54, 168, 255, 230) if active else (112, 128, 147, 135)
            if action == "stop":
                outline = (236, 76, 83, 200)
            draw.rounded_rectangle(box, radius=8, fill=fill, outline=outline)
            bounds = draw.textbbox((0, 0), label, font=self.button_font)
            x = (box[0] + box[2] - bounds[2] + bounds[0]) / 2
            y = (box[1] + box[3] - bounds[3] + bounds[1]) / 2 - bounds[1]
            draw.text((x, y), label, font=self.button_font, fill=(238, 241, 248, 255))
        if scale != 1.0:
            canvas = canvas.resize((round(CANVAS_SIZE[0] * scale), round(CANVAS_SIZE[1] * scale)),
                                   Image.Resampling.LANCZOS)
        return canvas


def _window_class(paths: Paths) -> str:
    # Stable for this profile, with no runtime credentials in window metadata.
    identity = str(paths.root.resolve()).casefold().encode("utf-8")
    return "JarvisTransparentOrb_" + hashlib.sha256(identity).hexdigest()[:16]


def _show_existing_windows(paths: Paths) -> bool:
    """A second shortcut invocation raises the existing orb without a panel."""
    import ctypes as ct
    from ctypes import wintypes as wt
    user32 = ct.WinDLL("user32", use_last_error=True)
    user32.FindWindowW.argtypes, user32.FindWindowW.restype = [wt.LPCWSTR, wt.LPCWSTR], wt.HWND
    user32.ShowWindow.argtypes, user32.ShowWindow.restype = [wt.HWND, ct.c_int], wt.BOOL
    user32.SetWindowPos.argtypes = [wt.HWND, wt.HWND, ct.c_int, ct.c_int, ct.c_int, ct.c_int, wt.UINT]
    user32.SetWindowPos.restype = wt.BOOL
    hwnd = user32.FindWindowW(_window_class(paths), None)
    if not hwnd:
        return False  # The first process may still be decoding its video asset.
    user32.ShowWindow(hwnd, 4)
    user32.SetWindowPos(hwnd, wt.HWND(-1), 0, 0, 0, 0, 0x0001 | 0x0002 | 0x0010)
    return True


def _run_windows(paths: Paths, clip: AnimationClip) -> int:
    """All Win32 objects and pointer signatures are defined only on Windows."""
    if os.name != "nt":
        raise DesktopError("Saydam JARVIS küresi Windows 10/11 masaüstünde çalışır.")
    import ctypes as ct
    from ctypes import wintypes as wt

    user32 = ct.WinDLL("user32", use_last_error=True)
    gdi32 = ct.WinDLL("gdi32", use_last_error=True)
    kernel32 = ct.WinDLL("kernel32", use_last_error=True)
    LRESULT = ct.c_ssize_t
    UINT_PTR = ct.c_size_t
    WNDPROC = ct.WINFUNCTYPE(LRESULT, wt.HWND, wt.UINT, wt.WPARAM, wt.LPARAM)

    class WNDCLASS(ct.Structure):
        _fields_ = [("style", wt.UINT), ("lpfnWndProc", WNDPROC), ("cbClsExtra", ct.c_int),
                    ("cbWndExtra", ct.c_int), ("hInstance", wt.HINSTANCE), ("hIcon", wt.HANDLE),
                    ("hCursor", wt.HANDLE), ("hbrBackground", wt.HBRUSH),
                    ("lpszMenuName", wt.LPCWSTR), ("lpszClassName", wt.LPCWSTR)]

    class MSG(ct.Structure):
        _fields_ = [("hwnd", wt.HWND), ("message", wt.UINT), ("wParam", wt.WPARAM),
                    ("lParam", wt.LPARAM), ("time", wt.DWORD), ("pt", wt.POINT),
                    ("lPrivate", wt.DWORD)]

    class BITMAPINFOHEADER(ct.Structure):
        _fields_ = [("biSize", wt.DWORD), ("biWidth", wt.LONG), ("biHeight", wt.LONG),
                    ("biPlanes", wt.WORD), ("biBitCount", wt.WORD), ("biCompression", wt.DWORD),
                    ("biSizeImage", wt.DWORD), ("biXPelsPerMeter", wt.LONG),
                    ("biYPelsPerMeter", wt.LONG), ("biClrUsed", wt.DWORD),
                    ("biClrImportant", wt.DWORD)]

    class BITMAPINFO(ct.Structure):
        _fields_ = [("bmiHeader", BITMAPINFOHEADER), ("bmiColors", wt.DWORD * 1)]

    class BLENDFUNCTION(ct.Structure):
        _fields_ = [("BlendOp", ct.c_ubyte), ("BlendFlags", ct.c_ubyte),
                    ("SourceConstantAlpha", ct.c_ubyte), ("AlphaFormat", ct.c_ubyte)]

    # ctypes defaults to 32-bit int return types. Every handle and LPARAM has an
    # explicit pointer-sized signature so this also works in 64-bit Python.
    def signature(lib, name, args, result):
        function = getattr(lib, name)
        function.argtypes, function.restype = args, result
        return function

    signature(kernel32, "GetModuleHandleW", [wt.LPCWSTR], wt.HMODULE)
    signature(user32, "RegisterClassW", [ct.POINTER(WNDCLASS)], wt.ATOM)
    signature(user32, "UnregisterClassW", [wt.LPCWSTR, wt.HINSTANCE], wt.BOOL)
    signature(user32, "CreateWindowExW", [wt.DWORD, wt.LPCWSTR, wt.LPCWSTR, wt.DWORD,
               ct.c_int, ct.c_int, ct.c_int, ct.c_int, wt.HWND, wt.HMENU, wt.HINSTANCE, wt.LPVOID], wt.HWND)
    signature(user32, "DefWindowProcW", [wt.HWND, wt.UINT, wt.WPARAM, wt.LPARAM], LRESULT)
    signature(user32, "DestroyWindow", [wt.HWND], wt.BOOL)
    signature(user32, "PostQuitMessage", [ct.c_int], None)
    signature(user32, "GetMessageW", [ct.POINTER(MSG), wt.HWND, wt.UINT, wt.UINT], ct.c_int)
    signature(user32, "TranslateMessage", [ct.POINTER(MSG)], wt.BOOL)
    signature(user32, "DispatchMessageW", [ct.POINTER(MSG)], LRESULT)
    signature(user32, "SetTimer", [wt.HWND, UINT_PTR, wt.UINT, ct.c_void_p], UINT_PTR)
    signature(user32, "KillTimer", [wt.HWND, UINT_PTR], wt.BOOL)
    signature(user32, "ShowWindow", [wt.HWND, ct.c_int], wt.BOOL)
    signature(user32, "GetDC", [wt.HWND], wt.HDC)
    signature(user32, "ReleaseDC", [wt.HWND, wt.HDC], ct.c_int)
    signature(user32, "UpdateLayeredWindow", [wt.HWND, wt.HDC, ct.POINTER(wt.POINT),
               ct.POINTER(wt.SIZE), wt.HDC, ct.POINTER(wt.POINT), wt.DWORD,
               ct.POINTER(BLENDFUNCTION), wt.DWORD], wt.BOOL)
    signature(user32, "GetCursorPos", [ct.POINTER(wt.POINT)], wt.BOOL)
    signature(user32, "GetWindowRect", [wt.HWND, ct.POINTER(wt.RECT)], wt.BOOL)
    signature(user32, "SetCapture", [wt.HWND], wt.HWND)
    signature(user32, "ReleaseCapture", [], wt.BOOL)
    signature(user32, "SetWindowPos", [wt.HWND, wt.HWND, ct.c_int, ct.c_int,
               ct.c_int, ct.c_int, wt.UINT], wt.BOOL)
    signature(user32, "SetForegroundWindow", [wt.HWND], wt.BOOL)
    signature(user32, "CreatePopupMenu", [], wt.HMENU)
    signature(user32, "AppendMenuW", [wt.HMENU, wt.UINT, UINT_PTR, wt.LPCWSTR], wt.BOOL)
    signature(user32, "TrackPopupMenu", [wt.HMENU, wt.UINT, ct.c_int, ct.c_int,
               ct.c_int, wt.HWND, ct.POINTER(wt.RECT)], wt.UINT)
    signature(user32, "DestroyMenu", [wt.HMENU], wt.BOOL)
    signature(user32, "LoadCursorW", [wt.HINSTANCE, wt.LPCWSTR], wt.HANDLE)
    signature(user32, "ValidateRect", [wt.HWND, ct.POINTER(wt.RECT)], wt.BOOL)
    signature(user32, "SystemParametersInfoW", [wt.UINT, wt.UINT, wt.LPVOID, wt.UINT], wt.BOOL)
    signature(gdi32, "CreateCompatibleDC", [wt.HDC], wt.HDC)
    signature(gdi32, "CreateDIBSection", [wt.HDC, ct.POINTER(BITMAPINFO), wt.UINT,
               ct.POINTER(ct.c_void_p), wt.HANDLE, wt.DWORD], wt.HBITMAP)
    signature(gdi32, "SelectObject", [wt.HDC, wt.HGDIOBJ], wt.HGDIOBJ)
    signature(gdi32, "DeleteObject", [wt.HGDIOBJ], wt.BOOL)
    signature(gdi32, "DeleteDC", [wt.HDC], wt.BOOL)

    try:
        signature(user32, "SetProcessDpiAwarenessContext", [ct.c_void_p], wt.BOOL)(ct.c_void_p(-4))
    except AttributeError:
        try:
            signature(user32, "SetProcessDPIAware", [], wt.BOOL)()
        except AttributeError:
            pass
    get_dpi = None
    try:
        get_dpi = signature(user32, "GetDpiForWindow", [wt.HWND], wt.UINT)
    except AttributeError:
        pass
    exclude_from_capture = None
    try:
        exclude_from_capture = signature(user32, "SetWindowDisplayAffinity", [wt.HWND, wt.DWORD], wt.BOOL)
    except AttributeError:
        pass

    backend = HudConnection(paths)
    renderer = OrbRenderer(clip)
    class_name = _window_class(paths)
    instance = kernel32.GetModuleHandleW(None)

    class Window:
        def __init__(self):
            self.hwnd = None
            self.scale = 1.0
            self.dc = None
            self.bitmap = None
            self.old_bitmap = None
            self.bits = ct.c_void_p()
            self.size = (0, 0)
            self.start = time.monotonic()
            self.press = None
            self.dragging = False
            self.graphics_failed = False
            self.callback = WNDPROC(self._procedure)

        def _free_bitmap(self):
            if self.dc and self.old_bitmap:
                gdi32.SelectObject(self.dc, self.old_bitmap)
            if self.bitmap:
                gdi32.DeleteObject(self.bitmap)
            if self.dc:
                gdi32.DeleteDC(self.dc)
            self.dc = self.bitmap = self.old_bitmap = None

        def _ensure_bitmap(self, size):
            if size == self.size and self.dc:
                return
            self._free_bitmap()
            self.dc = gdi32.CreateCompatibleDC(None)
            if not self.dc:
                raise ct.WinError(ct.get_last_error())
            info = BITMAPINFO()
            info.bmiHeader.biSize = ct.sizeof(BITMAPINFOHEADER)
            info.bmiHeader.biWidth, info.bmiHeader.biHeight = size[0], -size[1]
            info.bmiHeader.biPlanes, info.bmiHeader.biBitCount = 1, 32
            self.bitmap = gdi32.CreateDIBSection(self.dc, ct.byref(info), 0,
                                                ct.byref(self.bits), None, 0)
            if not self.bitmap or not self.bits.value:
                raise ct.WinError(ct.get_last_error())
            self.old_bitmap = gdi32.SelectObject(self.dc, self.bitmap)
            if not self.old_bitmap:
                raise ct.WinError(ct.get_last_error())
            self.size = size

        def draw(self):
            cursor, bounds = wt.POINT(), wt.RECT()
            user32.GetCursorPos(ct.byref(cursor))
            user32.GetWindowRect(self.hwnd, ct.byref(bounds))
            snapshot = backend.snapshot()
            hover = bounds.left <= cursor.x < bounds.right and bounds.top <= cursor.y < bounds.bottom
            frame = renderer.render(snapshot, (time.monotonic() - self.start) * 1000,
                                    self.scale, show_controls=hover or snapshot.state == 'error')
            self._ensure_bitmap(frame.size)
            data = premultiplied_bgra(frame)
            ct.memmove(self.bits, data, len(data))
            rect = wt.RECT()
            if not user32.GetWindowRect(self.hwnd, ct.byref(rect)):
                raise ct.WinError(ct.get_last_error())
            destination, source = wt.POINT(rect.left, rect.top), wt.POINT(0, 0)
            size = wt.SIZE(*frame.size)
            blend = BLENDFUNCTION(0, 0, 255, 1)
            screen = user32.GetDC(None)
            try:
                if not user32.UpdateLayeredWindow(self.hwnd, screen, ct.byref(destination), ct.byref(size),
                                                 self.dc, ct.byref(source), 0, ct.byref(blend), 2):
                    raise ct.WinError(ct.get_last_error())
            finally:
                if screen:
                    user32.ReleaseDC(None, screen)

        def _action(self, action):
            if action == "listen":
                state = backend.snapshot()
                action = "mute" if state.mic_enabled or state.state == "listening" else "listen"
            backend.action(action)

        def _context_menu(self):
            point = wt.POINT()
            user32.GetCursorPos(ct.byref(point))
            menu = user32.CreatePopupMenu()
            if not menu:
                return
            try:
                labels = [(1001, "Mikrofonu sustur" if backend.snapshot().mic_enabled else "Dinle"),
                          (1002, "Ayarlar"), (1003, "Acil durdur (F8)"), (1004, "JARVIS'i kapat")]
                for identifier, label in labels:
                    user32.AppendMenuW(menu, 0, identifier, label)
                user32.SetForegroundWindow(self.hwnd)
                selected = user32.TrackPopupMenu(menu, 0x0100 | 0x0080 | 0x0002,
                                                point.x, point.y, 0, self.hwnd, None)
                action = {1001: "listen", 1002: "settings", 1003: "stop", 1004: "close"}.get(selected)
                if action:
                    self._action(action)
            finally:
                user32.DestroyMenu(menu)

        def _procedure(self, hwnd, message, wparam, lparam):
            # Exceptions cannot cross a ctypes callback boundary.
            try:
                return self._dispatch(hwnd, message, wparam, lparam)
            except Exception:
                LOGGER.exception("Windows küre arayüzü işlemi başarısız")
                backend._set(HudSnapshot("error", "Küre arayüzünde hata oluştu"))
                # A failed graphics device must not create a 30fps log storm.
                if message == 0x0113:
                    self.graphics_failed = True
                return user32.DefWindowProcW(hwnd, message, wparam, lparam)

        def _dispatch(self, hwnd, message, wparam, lparam):
            if message == 0x0113:  # WM_TIMER
                if backend.close_window.is_set():
                    user32.DestroyWindow(hwnd)
                elif not self.graphics_failed:
                    self.draw()
                return 0
            if message == 0x000F:  # WM_PAINT; layered content is uploaded separately.
                user32.ValidateRect(hwnd, None)
                return 0
            if message == 0x0014:  # WM_ERASEBKGND
                return 1
            if message == 0x0021:  # WM_MOUSEACTIVATE / MA_NOACTIVATE
                return 3
            if message == 0x0201:  # WM_LBUTTONDOWN
                cursor, rect = wt.POINT(), wt.RECT()
                user32.GetCursorPos(ct.byref(cursor))
                user32.GetWindowRect(hwnd, ct.byref(rect))
                x = ct.c_short(lparam & 0xFFFF).value / self.scale
                y = ct.c_short((lparam >> 16) & 0xFFFF).value / self.scale
                button = next((action for action, box in BUTTONS
                               if box[0] <= x <= box[2] and box[1] <= y <= box[3]), None)
                self.press = (cursor.x, cursor.y, rect.left, rect.top, button)
                self.dragging = False
                user32.SetCapture(hwnd)
                return 0
            if message == 0x0200 and self.press:  # WM_MOUSEMOVE
                cursor = wt.POINT()
                user32.GetCursorPos(ct.byref(cursor))
                old_x, old_y, window_x, window_y, button = self.press
                dx, dy = cursor.x - old_x, cursor.y - old_y
                if button is None and (self.dragging or abs(dx) + abs(dy) > 5 * self.scale):
                    self.dragging = True
                    user32.SetWindowPos(hwnd, wt.HWND(-1), window_x + dx, window_y + dy,
                                        0, 0, 0x0001 | 0x0010)  # NOSIZE | NOACTIVATE
                return 0
            if message == 0x0202 and self.press:  # WM_LBUTTONUP
                button = self.press[4]
                self.press = None
                user32.ReleaseCapture()
                if button:
                    x = ct.c_short(lparam & 0xFFFF).value / self.scale
                    y = ct.c_short((lparam >> 16) & 0xFFFF).value / self.scale
                    box = next(box for action, box in BUTTONS if action == button)
                    if not (box[0] <= x <= box[2] and box[1] <= y <= box[3]):
                        return 0
                if not self.dragging:
                    self._action(button or "listen")
                return 0
            if message == 0x0215:  # WM_CAPTURECHANGED
                self.press = None
                return 0
            if message == 0x007B:  # WM_CONTEXTMENU
                self._context_menu()
                return 0
            if message == 0x0100 and wparam == 0x1B:  # WM_KEYDOWN / Escape
                backend.action("stop")
                return 0
            if message == 0x02E0:  # WM_DPICHANGED
                self.scale = max(0.75, min(4.0, (wparam & 0xFFFF) / 96.0))
                rect = ct.cast(lparam, ct.POINTER(wt.RECT)).contents
                user32.SetWindowPos(hwnd, None, rect.left, rect.top,
                                    round(CANVAS_SIZE[0] * self.scale), round(CANVAS_SIZE[1] * self.scale),
                                    0x0004 | 0x0010)  # NOZORDER | NOACTIVATE
                return 0
            if message == 0x0010:  # WM_CLOSE: close the assistant gracefully too.
                backend.action("close")
                return 0
            if message == 0x0002:  # WM_DESTROY
                user32.KillTimer(hwnd, 1)
                user32.PostQuitMessage(0)
                return 0
            return user32.DefWindowProcW(hwnd, message, wparam, lparam)

        def run(self):
            cursor = user32.LoadCursorW(None, ct.cast(ct.c_void_p(32512), wt.LPCWSTR))
            wc = WNDCLASS(0, self.callback, 0, 0, instance, None, cursor, None, None, class_name)
            if not user32.RegisterClassW(ct.byref(wc)):
                raise ct.WinError(ct.get_last_error())
            try:
                work = wt.RECT(0, 0, 1024, 768)
                user32.SystemParametersInfoW(48, 0, ct.byref(work), 0)  # SPI_GETWORKAREA
                x = max(work.left, work.right - CANVAS_SIZE[0] - 28)
                y = max(work.top, work.bottom - CANVAS_SIZE[1] - 28)
                self.hwnd = user32.CreateWindowExW(0x00080000 | 0x00000008 | 0x00000080 | 0x08000000,
                            class_name, "JARVIS", 0x80000000, x, y, *CANVAS_SIZE,
                            None, None, instance, None)
                if not self.hwnd:
                    raise ct.WinError(ct.get_last_error())
                if exclude_from_capture and sys.getwindowsversion().build >= 19041:
                    # Supported on Windows 10 2004+. A failed call leaves normal
                    # desktop capture intact; we never hide the user's desktop.
                    exclude_from_capture(self.hwnd, 0x00000011)
                if get_dpi:
                    self.scale = max(0.75, min(4.0, get_dpi(self.hwnd) / 96.0))
                    width, height = (round(dimension * self.scale) for dimension in CANVAS_SIZE)
                    user32.SetWindowPos(self.hwnd, None, max(work.left, work.right - width - 28),
                                        max(work.top, work.bottom - height - 28), width, height,
                                        0x0004 | 0x0010)
                self.draw()
                user32.ShowWindow(self.hwnd, 4)  # SW_SHOWNOACTIVATE
                if not user32.SetTimer(self.hwnd, 1, 33, None):
                    raise ct.WinError(ct.get_last_error())
                backend.start()
                message = MSG()
                while True:
                    result = user32.GetMessageW(ct.byref(message), None, 0, 0)
                    if result == -1:
                        raise ct.WinError(ct.get_last_error())
                    if result == 0:
                        return int(message.wParam)
                    user32.TranslateMessage(ct.byref(message))
                    user32.DispatchMessageW(ct.byref(message))
            finally:
                backend.stopping.set()
                if self.hwnd:
                    user32.DestroyWindow(self.hwnd)
                self._free_bitmap()
                user32.UnregisterClassW(class_name, instance)

    return Window().run()


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="JARVIS saydam Windows masaüstü küresi")
    parser.add_argument("--state-dir", help="Yerel çalışma verisi klasörü")
    options = parser.parse_args(argv)
    paths = application_paths(options.state_dir)
    paths.prepare()
    handler = RotatingFileHandler(paths.logs / "overlay.log", maxBytes=500_000,
                                  backupCount=2, encoding="utf-8")
    handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
    LOGGER.addHandler(handler)
    LOGGER.setLevel(logging.INFO)
    lock = InstanceLock(paths.root / "overlay.lock")
    try:
        if os.name != "nt":
            raise DesktopError("Saydam JARVIS küresi Windows 10/11 masaüstünde çalışır.")
        if not lock.acquire():
            _show_existing_windows(paths)
            return 0
        return _run_windows(paths, AnimationClip())
    except Exception:
        LOGGER.exception("JARVIS saydam masaüstü arayüzü başlatılamadı")
        if os.name == "nt":
            import ctypes
            ctypes.windll.user32.MessageBoxW(None,
                "JARVIS küresi başlatılamadı. Günlük: " + str(paths.logs / "overlay.log"),
                "JARVIS", 0x10)
        return 1
    finally:
        lock.release()


if __name__ == "__main__":
    raise SystemExit(main())
