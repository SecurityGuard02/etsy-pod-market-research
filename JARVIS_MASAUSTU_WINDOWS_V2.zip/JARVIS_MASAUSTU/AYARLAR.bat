@echo off
setlocal
title JARVIS - Ayarlar
set "JARVIS_PY=%LOCALAPPDATA%\JarvisEtsy\program\runtime\pythonw.exe"
if not exist "%JARVIS_PY%" (
  echo Once KUR.bat dosyasini calistirin.
  pause
  exit /b 1
)
start "" "%JARVIS_PY%" -m jarvis.desktop --settings
exit /b 0
