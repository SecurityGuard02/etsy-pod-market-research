@echo off
setlocal
title JARVIS - Durdur
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1" -Action Stop
set "JARVIS_EXIT=%ERRORLEVEL%"
echo.
pause
exit /b %JARVIS_EXIT%
