@echo off
setlocal
title JARVIS - Baslat
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1" -Action Launch
if errorlevel 1 (
    pause
    exit /b 1
)
exit /b 0
