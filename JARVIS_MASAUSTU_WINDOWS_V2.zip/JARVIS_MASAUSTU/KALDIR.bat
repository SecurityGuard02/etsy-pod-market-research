@echo off
setlocal
title JARVIS - Kaldir
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1" -Action Uninstall
set "JARVIS_EXIT=%ERRORLEVEL%"
echo.
pause
exit /b %JARVIS_EXIT%
