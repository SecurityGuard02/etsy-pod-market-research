@echo off
setlocal
title JARVIS - Otomatik baslatmayi kapat
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1" -Action DisableStartup
set "JARVIS_EXIT=%ERRORLEVEL%"
echo.
pause
exit /b %JARVIS_EXIT%
