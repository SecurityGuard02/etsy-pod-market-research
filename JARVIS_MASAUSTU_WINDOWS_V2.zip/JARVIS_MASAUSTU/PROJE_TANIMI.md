# JARVIS — masaüstü asistanı ve Etsy POD iş akışı

Bu paket Windows 10/11, 64 bit için bağımsız hazırlanmıştır. Referans olarak gönderilen JARVIS_V13_KURULUM.zip'in içeriği çalıştırılmamış, kodu veya ayarları bu uygulamaya aktarılmamıştır.

## Kullanıcı deneyimi

Uygulama açıldığında büyük bir kontrol paneli yerine şeffaf, sürüklenebilir ve üstte kalan bir küre görünür. Kullanıcının sağladığı video, enerji küresinin ışığı, halkaları ve parçacık görünümü için görsel referanstır. Yeni animasyon, hacimli parçacık alanı ve ışık katmanları kodla hesaplanarak özgün olarak üretilmiştir. Arayüzde referans video veya videodan çıkarılmış kareler oynatılmaz. Özgün animasyonun saydam kareleri yerel olarak oynatılır; video sesi kullanılmaz. Orijinal video assets/jarvis_reference.mp4 dosyasında yalnız referans olarak korunur.

- Sıcak altın: hazır, bekliyor veya bir işlemi hazırlıyor.
- Mavi: mikrofon gerçekten kayıt yapıyor.
- Turuncu: JARVIS'in sesli yanıtı hoparlörden çalınıyor.
- Kırmızı: bir hata oluşmuş; durum metni de hatayı açıklar.

Mikrofon izninin açık olması tek başına mavi renge geçirmez. Sesin metne çevrilmesi veya sesli yanıtın API'den hazırlanması aktif dinleme/konuşma sayılmaz; renk, kaydın ya da oynatmanın durumuyla değişir.

Küreye tıklamak mikrofon kaydını başlatır veya süren ses işlemini durdurur. Mikrofon ancak ayarlardan izin verilmişse açılır. Sağ tık menüsü / küçük ayarlar düğmesi kontrol panelini açar. Küre sürüklenerek taşınabilir. Varsayılan sürekli mikrofon dinleme ve gizli ekran kaydı yoktur.

## Ekran, fare ve klavye

Ekran/fare/klavye erişimini panelde açın. Sesle ya da görev alanına yazarak görev verin. Panelden görev gönderiyorsanız üç saniye içinde işlem yapılacak pencereye geçin. Mikrofon düğmesi hedef pencerenin odağını almadan kullanılabilir.

Asistan ana ekranın görüntüsünü alır ve OpenAI görsel modelinden yalnız bir sonraki adımı ister. Ekran görüntüsü bu amaçla OpenAI'ye gönderilir. Önerilen eylem, açıklaması ve ekran önizlemesi panelde ve bağlı Telegram hesabında gösterilir. Onay verilmeden fare/klavye işlemi yapılmaz. Onaydan sonra yalnız bir eylem uygulanır; yeni ekran incelenir ve yeni adım için yeniden onay istenir.

Fare hareketi/tıklama, çift tıklama, kaydırma, normal metin yazma ve izinli klavye kısayolları desteklenir. Türkçe karakterler Unicode olarak yazılır. Görüntü koordinatları gerçek ekran boyutuna çevrilir. Onaylanan pencere değişmişse veya hedef bölge farklıysa yanlış yere tıklamak yerine işlem durur. Yayınlama/gönderme gibi kritik adımlarda ayrı son onay gerekir.

F8 veya fareyi ekranın sol üst köşesine götürmek etkin masaüstü görevini durdurur. Kürenin acil durdur düğmesi de kontrolü ve sesi durdurur, bekleyen yayın onaylarını iptal eder ve programı duraklatır. Gönderilmiş bir uzak API işlemi geriye alınamaz.

İlk sürüm ana monitörü kullanır. Kilit ekranı/UAC güvenli ekranı, ödeme, parola ve doğrulama kodu girişleri kullanıcıya bırakılır. Uygulama yönetici yetkisi yükseltmez; terminal, keyfi kod/betik veya sistem komutu çalıştıran bir bilgisayar ajanı değildir. Her uygulamada ve her karmaşık görevde başarı garantisi verilmez.

## Ses

Mikrofon kaydı isteğe bağlıdır; tek kayıt en fazla 15 saniyedir ve sessizlikle sonlanabilir. Ses Türkçe metne çevrilir. Sesli talep, işlem onayı yerine geçmez. Fare/klavye ve yayın işlemleri yine ayrı kartlarla onaylanır.

Yanıt sesi OpenAI gpt-4o-mini-tts / onyx profiliyle Türkçe, tok, sakin ve anlaşılır olacak şekilde istenir. Gerçek tınıyı ses testinde dinleyin. Ses yapay zekâ ile üretilir. Ses kaydı bellekte işlenir; kalıcı ses arşivi tutulmaz. API erişimi ve faturalandırma gerekir.

## Etsy / Printify / sosyal medya akışı

1. Pazartesi, çarşamba ve cuma 09.00 Europe/Istanbul zamanlayıcısı araştırma başlatır. Programı bağlantı testlerinden sonra açın. Önceki paket bekliyorsa yeni ücretli üretim yığılmaz.
2. Araştırma Etsy/Pinterest ve erişilebilir kaynakların gözlenebilen göstergelerini, bağlantılarını ve belirsizliklerini raporlar. Rakip kesin satış adedi, genel Pinterest beğeni sıralaması veya satış nedenleri uydurulmaz; nedenler hipotez olarak ayrılır.
3. Araştırma onaylanınca beş farklı özgün baskı görseli üretilir ve Telegram'a gönderilir. Her tasarım ayrı seçilir. Başkasının tasarımının kopyası, marka/karakter/logosu veya lisanssız öğe kullanılmamalıdır.
4. Printify'ın gerçek kataloğundan ürün, tedarikçi, renk/beden varyantları ve baskı yerleşimi seçilir. Başlık, açıklama, etiket ve fiyat önerisi onaya sunulur. Maliyet verisi yoksa en ucuz sağlayıcı veya kesin kâr iddiası yapılmaz.
5. Onaylı planla Printify'da yayınlanmamış ürün oluşturulur. Gerçek giysi mockup'ı incelenir. Ardından ayrı onayla Etsy taslağı oluşturulur ve gerçek alanlar/envanter geri okunur.
6. Etsy'deki son taslak, fiyat, başlık, metin, etiket ve varyantlar son kez gösterilir. Yayından hemen önce değişiklik denetlenir. Son açık onay olmadan etkin listeleme yapılmaz.
7. Yayın doğrulanınca onayla, gerçek giysi mockup'ını referans alan yeni yetişkin sentetik mankenli görsel ve sosyal metin hazırlanır. Baskının değişmediği kullanıcı tarafından kontrol edilir. Instagram ve Pinterest için ayrı onay alınır.

Hesap API'leri güvenilir ve yapılandırılmış işlemler için kullanılır. Masaüstü operatörü, tarayıcıda görünür görevlerin ekran/fare/klavye yoluyla uygulanması için ayrıca kullanılabilir. Genel görsel ajanı ile API iş akışının uzak ürün kimlikleri otomatik uzlaştırılmaz: API'de hazırlanmış ürünü aynı anda tarayıcıdan yeniden oluşturmayın. Aynı ürünü iki yürütme yoluyla çoğaltmayın.

Satış sonrası siparişlerin Printify üretimine otomatik aktarımı bu sürümde kurulmamıştır; sipariş/üretim takibi manueldir. Üretim ortağı, kargo, iade ve üretim süresi gibi mağaza politikaları doğru olmalıdır. Baskı çözünürlüğü ve yerleşimi ürün kartında gösterilir; satış öncesi fiziksel numune önerilir.

## Kurulumda size kalanlar

ZIP'i tamamen ayıklayın, KUR.bat'a çift tıklayın. Python ve bağımlılıklar pakette bulunur. Masaüstü kısayolu oluşturulur. Ayarları sağ tıktan veya AYARLAR.bat ile açın. OpenAI ve Telegram bilgilerini ekleyin, Telegram eşleştirmesini tamamlayın. Ekran ve mikrofon izinlerini ihtiyacınıza göre açın.

Etsy, Printify, Instagram ve Pinterest hesaplarını ilgili API/yetki alanlarından bağlayın. Bazı platformlarda profesyonel hesap ve geliştirici uygulama incelemesi gerekir. API anahtarı, hesap erişim izninin yerine geçmez. Yerel HTTPS geri dönüş adresini destekleyen OAuth hesaplarında panelin gösterdiği adresi kaydedin; izin sonrası tarayıcıda oluşan son URL'yi panelde tamamlayın. Sertifika uyarısı atlatılmaz. Platform localhost yönlendirmesini kabul etmiyorsa kendi yetkili erişim tokenınızı sağlamanız gerekir.

Instagram'ın görseli dışarıdan alabilmesi için masaüstü sürümünde isteğe bağlı Cloudinary bağlantısı vardır. Yalnız Instagram paylaşımına açık onaydan sonra görsel bu hesaba yüklenir. Pinterest görseli doğrudan API ile alabilir. Bu bağlantılar kendi hizmet hesaplarınızın koşullarına tabidir.

API bilgileri yerel diskte şifreli tutulur; kullanıcı verileri %LOCALAPPDATA%\JarvisEtsy\data altındadır. Bu dizin ve şifreleme anahtarı birlikte yedeklenmelidir. Paket hiçbir gerçek hesap anahtarı içermez.

## Mevcut kurulumu güncelleme

Yeni ZIP'i ayrı bir klasöre tamamen ayıklayın ve o klasördeki KUR.bat dosyasına çift tıklayın. Kurulum JARVIS'in kendi çalışan örneğini durdurur, yeni programı denetleyip yerleştirir ve yeniden başlatır. API ayarları, şifreleme anahtarı, Telegram eşleştirmesi, izinler ve ürün verileri aynı kullanıcı veri dizininde korunur. Eski program dosyaları ayrıca yedeklenir. Güncelleme için KALDIR.bat'ı çalıştırmanız veya kullanıcı verilerini silmeniz gerekmez.

## Doğrulama sınırı

Kod, onay akışları, gerçek yerel sunucu başlatma/durdurma/yeniden başlatma, tarayıcı arayüzü, özgün animasyonun saydamlığı, durum renkleri, paket bütünlüğü ve resmî Windows çalışma zamanı/bağımlılık hash'leri bu geliştirme ortamında kontrol edilir. Bu ortam Linux'tur. Windows'ta gerçek fare, mikrofon, hoparlör, şeffaf pencere ve canlı mağaza hesaplarıyla birebir uçtan uca test yapılmamıştır. Bu özelliklerin donanım/hesap üzerinde doğrulanması ilk çalıştırmanın parçasıdır.

Bilgisayar kapalıyken, uykudayken veya JARVIS çalışmıyorken masaüstü görevleri yürütülemez. Sürekli çalışması için bilgisayar açık/uyanık ve internete bağlı kalmalıdır. Otomatik başlangıç ayrı dosyayla isteğe bağlı açılır; kurulumda kendiliğinden etkinleşmez.
