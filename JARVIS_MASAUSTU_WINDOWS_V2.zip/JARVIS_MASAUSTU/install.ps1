[CmdletBinding()]
param(
    [ValidateSet('Install', 'Launch', 'Stop', 'Uninstall', 'EnableStartup', 'DisableStartup')]
    [string]$Action = 'Install'
)

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$BundleRoot = $PSScriptRoot
$InstallRoot = Join-Path ([Environment]::GetFolderPath('LocalApplicationData')) 'JarvisEtsy'
$ProgramRoot = Join-Path $InstallRoot 'program'
$DataRoot = Join-Path $InstallRoot 'data'
$MarkerPath = Join-Path $InstallRoot 'installation.json'
$Python = Join-Path $ProgramRoot 'runtime\python.exe'
$PythonWindowless = Join-Path $ProgramRoot 'runtime\pythonw.exe'
$AppRoot = Join-Path $ProgramRoot 'app'
$MarkerType = 'jarvis-desktop-windows-v1'
$StartMenuRoot = Join-Path ([Environment]::GetFolderPath('StartMenu')) 'Programs\JARVIS Etsy'
$DesktopLink = Join-Path ([Environment]::GetFolderPath('DesktopDirectory')) 'JARVIS Etsy.lnk'
$StartupLink = Join-Path ([Environment]::GetFolderPath('Startup')) 'JARVIS Etsy.lnk'

function Assert-NoReparsePoint([string]$Path) {
    if (Test-Path -LiteralPath $Path) {
        $item = Get-Item -LiteralPath $Path -Force
        if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
            throw "Baglanti/junction yolu kullanilamaz: $Path"
        }
    }
}

function Assert-TreeNoReparsePoint([string]$Path) {
    Assert-NoReparsePoint $Path
    if (Test-Path -LiteralPath $Path -PathType Container) {
        foreach ($item in Get-ChildItem -LiteralPath $Path -Recurse -Force) {
            if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
                throw "Klasorde baglanti/junction bulundu; dosyalar korunuyor: $($item.FullName)"
            }
        }
    }
}

function Test-ManagedInstallation {
    if (-not (Test-Path -LiteralPath $MarkerPath -PathType Leaf)) { return $false }
    Assert-NoReparsePoint $MarkerPath
    $marker = Get-Content -LiteralPath $MarkerPath -Raw -Encoding UTF8 | ConvertFrom-Json
    return $marker.type -eq $MarkerType
}

function Assert-ManagedInstallation {
    Assert-NoReparsePoint $InstallRoot
    Assert-NoReparsePoint $ProgramRoot
    if (-not (Test-ManagedInstallation)) {
        throw "Gecerli JARVIS kurulumu bulunamadi. ZIP klasorundeki KUR.bat dosyasini calistirin."
    }
}

function Stop-Jarvis {
    if (-not (Test-Path -LiteralPath $Python -PathType Leaf)) { return }
    Assert-ManagedInstallation
    Push-Location -LiteralPath $AppRoot
    try {
        & $Python -m jarvis.desktop --stop
        if ($LASTEXITCODE -ne 0) {
            throw 'JARVIS durdurulamadi. Uygulamayi kapatip yeniden deneyin.'
        }
    } finally { Pop-Location }
}

function New-AppShortcut([string]$Path) {
    $parent = Split-Path -Parent $Path
    [IO.Directory]::CreateDirectory($parent) | Out-Null
    $shell = New-Object -ComObject WScript.Shell
    if (Test-Path -LiteralPath $Path) {
        Assert-NoReparsePoint $Path
        $old = $shell.CreateShortcut($Path)
        if ($old.TargetPath -ne $PythonWindowless) {
            throw "Ayni adli mevcut kisayol korunuyor: $Path"
        }
    }
    $shortcut = $shell.CreateShortcut($Path)
    $shortcut.TargetPath = $PythonWindowless
    $shortcut.Arguments = '-m jarvis.desktop'
    $shortcut.WorkingDirectory = $AppRoot
    $shortcut.Description = 'JARVIS Etsy asistani'
    $icon = Join-Path $AppRoot 'jarvis\assets\jarvis.ico'
    if (Test-Path -LiteralPath $icon -PathType Leaf) { $shortcut.IconLocation = $icon }
    $shortcut.Save()
}

function Remove-AppShortcut([string]$Path) {
    if (Test-Path -LiteralPath $Path -PathType Leaf) {
        Assert-NoReparsePoint $Path
        $shell = New-Object -ComObject WScript.Shell
        if ($shell.CreateShortcut($Path).TargetPath -eq $PythonWindowless) {
            Remove-Item -LiteralPath $Path
        }
    }
}

function Start-Jarvis {
    Assert-ManagedInstallation
    if (-not (Test-Path -LiteralPath $PythonWindowless -PathType Leaf)) {
        throw 'Python calistiricisi bulunamadi. KUR.bat ile kurulumu yenileyin.'
    }
    Start-Process -FilePath $PythonWindowless -ArgumentList '-m', 'jarvis.desktop' -WorkingDirectory $AppRoot
    Write-Host 'JARVIS baslatildi. Yerel panel tarayicinizda acilacak.'
}

function Read-VerifiedManifest {
    $manifestPath = Join-Path $BundleRoot 'manifest.json'
    if (-not (Test-Path -LiteralPath $manifestPath -PathType Leaf)) {
        throw 'manifest.json bulunamadi. ZIP dosyasinin tamamini bir klasore cikarin.'
    }
    Assert-NoReparsePoint $manifestPath
    $manifest = Get-Content -LiteralPath $manifestPath -Raw -Encoding UTF8 | ConvertFrom-Json
    if ($manifest.format -ne 1 -or -not $manifest.files -or $manifest.files.Count -eq 0) {
        throw 'Paket dosya listesi gecersiz.'
    }
    $seen = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
    $files = @()
    foreach ($entry in $manifest.files) {
        $relative = [string]$entry.path
        if ($relative -notmatch '^payload/(runtime|app|vendor)/[^\\:]+$' -or
            $relative -match '(^|/)(\.|\.\.)(/|$)' -or
            $relative -match '[\x00-\x1f<>"|?*]' -or
            $relative -match '(^|/)[^/]*[. ](/|$)' -or
            ([string]$entry.sha256) -notmatch '^[0-9a-fA-F]{64}$' -or
            -not $seen.Add($relative)) {
            throw "Gecersiz veya yinelenen paket yolu: $relative"
        }
        $source = Join-Path $BundleRoot ($relative.Replace('/', '\'))
        if (-not (Test-Path -LiteralPath $source -PathType Leaf)) {
            throw "Paket dosyasi eksik: $relative"
        }
        $sourceItem = Get-Item -LiteralPath $source -Force
        Assert-NoReparsePoint $source
        $cursor = $sourceItem.Directory
        while ($cursor -and $cursor.FullName -ne $BundleRoot) {
            if (($cursor.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
                throw "Paket sembolik baglanti iceriyor: $relative"
            }
            $cursor = $cursor.Parent
        }
        if ((Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash -ne $entry.sha256) {
            throw "Paket butunluk kontrolu basarisiz: $relative"
        }
        $files += [PSCustomObject]@{ Path = $relative; Source = $source; Hash = [string]$entry.sha256 }
    }
    $payloadPath = Join-Path $BundleRoot 'payload'
    Assert-NoReparsePoint $payloadPath
    foreach ($item in Get-ChildItem -LiteralPath $payloadPath -Recurse -Force) {
        if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
            throw "Paket sembolik baglanti iceriyor: $($item.FullName)"
        }
        if (-not $item.PSIsContainer) {
            $relative = $item.FullName.Substring($BundleRoot.Length + 1).Replace('\', '/')
            if (-not $seen.Contains($relative)) { throw "Listelenmemis paket dosyasi: $relative" }
        }
    }
    return ,$files
}

function Install-Jarvis {
    if (-not [Environment]::Is64BitOperatingSystem) {
        throw 'Bu paket Windows 10/11 64 bit icindir.'
    }
    Write-Host 'Paket butunlugu denetleniyor. Bu islem biraz surebilir...'
    $files = Read-VerifiedManifest
    foreach ($required in @('payload/runtime/python.exe', 'payload/runtime/pythonw.exe', 'payload/app/jarvis/desktop.py')) {
        if (-not ($files.Path -contains $required)) { throw "Gerekli dosya eksik: $required" }
    }
    Assert-NoReparsePoint $InstallRoot
    Assert-NoReparsePoint $ProgramRoot
    Assert-NoReparsePoint $DataRoot
    if (-not (Test-ManagedInstallation)) {
        foreach ($reserved in @('installation.json', 'installed-manifest.json')) {
            if (Test-Path -LiteralPath (Join-Path $InstallRoot $reserved)) {
                throw "Mevcut ozel dosya korunuyor: $(Join-Path $InstallRoot $reserved)"
            }
        }
    }
    if ((Test-Path -LiteralPath $ProgramRoot) -and -not (Test-ManagedInstallation)) {
        throw "Mevcut klasor korunuyor: $ProgramRoot . Bu klasoru elle baska yere tasiyip yeniden deneyin."
    }
    [IO.Directory]::CreateDirectory($InstallRoot) | Out-Null
    [IO.Directory]::CreateDirectory($DataRoot) | Out-Null
    $stage = Join-Path $InstallRoot ('program.stage.' + [Guid]::NewGuid().ToString('N'))
    $backup = $null
    try {
        [IO.Directory]::CreateDirectory($stage) | Out-Null
        foreach ($file in $files) {
            $destination = Join-Path $stage ($file.Path.Substring('payload/'.Length).Replace('/', '\'))
            [IO.Directory]::CreateDirectory((Split-Path -Parent $destination)) | Out-Null
            [IO.File]::Copy($file.Source, $destination, $false)
            if ((Get-FileHash -LiteralPath $destination -Algorithm SHA256).Hash -ne $file.Hash) {
                throw "Kopyalanan dosyanin butunlugu dogrulanamadi: $($file.Path)"
            }
        }
        Write-Host 'Windows calisma zamani ve ses/ekran modulleri denetleniyor...'
        $stagePython = Join-Path $stage 'runtime\python.exe'
        & $stagePython -c "import ctypes,io,fastapi,httpx,cryptography; from PIL import Image; from zoneinfo import ZoneInfo; import jarvis.overlay,jarvis.voice,jarvis.operator; assert ctypes.sizeof(ctypes.c_void_p)==8; ZoneInfo('Europe/Istanbul'); ctypes.WinDLL('user32'); ctypes.WinDLL('winmm'); b=io.BytesIO(); Image.new('RGBA',(2,2)).save(b,format='WEBP'); Image.open(io.BytesIO(b.getvalue())).load(); print('JARVIS on kontrolu tamamlandi.')"
        if ($LASTEXITCODE -ne 0) { throw 'Windows calisma zamani on kontrolu basarisiz; mevcut program degistirilmedi.' }
        # An upgrade keeps the complete previous program as a backup, including local custom files.
        if (Test-Path -LiteralPath $ProgramRoot) {
            Stop-Jarvis
            $backup = Join-Path $InstallRoot ('program.backup.' + [DateTime]::UtcNow.ToString('yyyyMMddHHmmss') + '.' + [Guid]::NewGuid().ToString('N').Substring(0, 8))
            Move-Item -LiteralPath $ProgramRoot -Destination $backup
        }
        try { Move-Item -LiteralPath $stage -Destination $ProgramRoot }
        catch {
            if ($backup -and -not (Test-Path -LiteralPath $ProgramRoot)) {
                Move-Item -LiteralPath $backup -Destination $ProgramRoot
            }
            throw
        }
        @{ type = $MarkerType; installedUtc = [DateTime]::UtcNow.ToString('o') } |
            ConvertTo-Json | Set-Content -LiteralPath $MarkerPath -Encoding UTF8
        Copy-Item -LiteralPath (Join-Path $BundleRoot 'manifest.json') -Destination (Join-Path $InstallRoot 'installed-manifest.json') -Force
        New-AppShortcut $DesktopLink
        New-AppShortcut (Join-Path $StartMenuRoot 'JARVIS Etsy.lnk')
        Write-Host "Kurulum tamamlandi: $InstallRoot"
        Write-Host "API ayarlari ve urun verileri: $DataRoot"
        if ($backup) { Write-Host "Onceki program ve ozel dosyalari korundu: $backup" }
        Start-Jarvis
    } finally {
        if (Test-Path -LiteralPath $stage) { Remove-Item -LiteralPath $stage -Recurse -Force }
    }
}

function Uninstall-Jarvis {
    Assert-ManagedInstallation
    Write-Host "Kaldirilacak program: $ProgramRoot"
    $answer = Read-Host 'JARVIS kaldirilsin mi? [E/H] (varsayilan H)'
    if ($answer -notin @('E', 'e', 'Y', 'y')) { Write-Host 'Iptal edildi.'; return }
    Stop-Jarvis
    Remove-AppShortcut $DesktopLink
    Remove-AppShortcut (Join-Path $StartMenuRoot 'JARVIS Etsy.lnk')
    Remove-AppShortcut $StartupLink
    Assert-TreeNoReparsePoint $ProgramRoot
    Remove-Item -LiteralPath $ProgramRoot -Recurse -Force
    $removeData = Read-Host 'API ayarlari ve tum veriler de silinsin mi? Silmek icin SIL yazin; Enter ile korunur'
    if ($removeData -ceq 'SIL') {
        Assert-TreeNoReparsePoint $DataRoot
        if (Test-Path -LiteralPath $DataRoot) { Remove-Item -LiteralPath $DataRoot -Recurse -Force }
        Write-Host 'Kullanici verileri silindi.'
    } else { Write-Host "Kullanici verileri korundu: $DataRoot" }
    Remove-Item -LiteralPath $MarkerPath -Force
    Write-Host 'Program kaldirildi. Yedekler ve diger mevcut dosyalar korunmustur.'
}

try {
    switch ($Action) {
        'Install' { Install-Jarvis }
        'Launch' {
            if (-not (Test-Path -LiteralPath $PythonWindowless -PathType Leaf)) { Install-Jarvis }
            else { Start-Jarvis }
        }
        'Stop' { Stop-Jarvis; Write-Host 'JARVIS durduruldu.' }
        'Uninstall' { Uninstall-Jarvis }
        'EnableStartup' {
            Assert-ManagedInstallation
            New-AppShortcut $StartupLink
            Write-Host 'JARVIS bu Windows kullanicisi oturum actiginda baslayacak.'
        }
        'DisableStartup' {
            Remove-AppShortcut $StartupLink
            Write-Host 'Otomatik baslatma kapatildi.'
        }
    }
    exit 0
} catch {
    Write-Host ('HATA: ' + $_.Exception.Message) -ForegroundColor Red
    Write-Host 'Islem tamamlanamadi. Kurulum icin ZIP dosyasini tam cikardiginizi kontrol edin.'
    exit 1
}
