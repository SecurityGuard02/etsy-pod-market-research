from __future__ import annotations

import asyncio
import base64
from contextlib import asynccontextmanager
from datetime import datetime
import hashlib
import hmac
import json
import math
import os
from pathlib import Path
import secrets
import time
from urllib.parse import urlencode, urlsplit, parse_qs
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

import httpx
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, JSONResponse, RedirectResponse, Response

from .store import Store, SECRET_FIELDS, DEFAULTS
from .providers import (EtsyClient, InstagramClient, OpenAIClient, PinterestClient,
                        PrintifyClient, TelegramClient, ProviderError)
from .engine import Engine


ALLOWED_SETTINGS = set(DEFAULTS) | SECRET_FIELDS | {
    'telegram_chat_id', 'telegram_user_id', 'etsy_shop_id', 'instagram_account_id',
    'instagram_login_type', 'instagram_client_id', 'pinterest_board_id', 'pinterest_client_id',
    'printify_shop_id', 'printify_blueprint_id', 'printify_provider_id',
    'etsy_shipping_profile_id', 'etsy_readiness_state_id', 'etsy_taxonomy_id',
    'etsy_return_policy_id', 'production_partner_ids', 'colors', 'sizes',
    'pinterest_region', 'etsy_token_expires_at', 'pinterest_token_expires_at',
    'instagram_api_version', 'min_margin', 'etsy_fee_rate', 'fixed_fees',
    'cloudinary_cloud_name',
}


def create_app(data_dir=None, workers=True, desktop_control=None):
    store = Store(data_dir or os.getenv('JARVIS_DATA_DIR', 'data'))
    engine = Engine(store)
    tasks = set()
    rate_limits = {}
    desktop_mode = desktop_control is not None
    desktop_nonces = {}
    hud = {'state': 'idle', 'message': 'Hazır. Dinlemek için küreye tıklayın.'}
    hud_error = {'message': ''}
    operator = voice = None
    voice_reply = {'message': ''}
    listen_pending = False
    if desktop_mode:
        if len(desktop_control.get('token', '')) < 32:
            raise ValueError('Masaüstü kontrol anahtarı eksik.')
        base = urlsplit(store.get_settings()['public_url'])
        if base.scheme != 'http' or base.hostname not in ('127.0.0.1', 'localhost', '::1'):
            raise ValueError('Masaüstü yalnız yerel döngü adresinden çalıştırılabilir.')
        from .operator import DesktopOperator
        from .voice import VoiceService
        operator = DesktopOperator(store)

        def voice_state(name, message):
            hud.update(state=name, message=message)
            if name == 'error':
                hud_error['message'] = message
            elif name in ('listening', 'speaking'):
                # A newly started capture or successful playback supersedes a
                # previous voice failure. Otherwise a retry can keep the orb
                # red even while the speaker is actually playing the reply.
                hud_error['message'] = ''

        async def voice_command(text):
            normalized = text.casefold().strip(' .!?')
            for name in ('jarvis', 'carvis', 'cervis'):
                if normalized.startswith(name + ' ') or normalized.startswith(name + ','):
                    normalized = normalized[len(name):].lstrip(' ,:')
                    break
            if normalized in ('durdur', 'acil durdur', 'iptal et', 'dur'):
                emergency_stop()
                reply = 'Durduruldu. Bekleyen yayın izinleri iptal edildi.'
            elif normalized in ('devam et', 'devam', 'duraklatmayı kaldır'):
                store.update_settings({'paused': False})
                reply = 'Duraklatma kaldırıldı. Eski onaylar tekrar kullanılmayacak.'
            elif normalized in ('durum', 'durum nedir', 'ne durumdasın'):
                reply = ('Asistan duraklatılmış.' if store.get_settings().get('paused') else
                         'Hazırım. Her masaüstü adımında onayını bekleyeceğim.')
            elif normalized in ('ayarları aç', 'paneli aç', 'kontrol panelini aç'):
                from .desktop import open_window
                await asyncio.to_thread(open_window, new_desktop_url())
                reply = 'Ayarlar açıldı.'
            elif normalized in ('araştırmayı başlat', 'etsy araştırmasını başlat', 'pazar araştırmasını başlat'):
                await engine.run_campaign()
                reply = 'Araştırma raporu hazır. Tasarım üretiminden önce Telegram onayını bekleyeceğim.'
            else:
                hud.update(state='working', message='Ekran inceleniyor; ilk adım onaya hazırlanıyor.')
                result = await operator.plan_task(text)
                await notify_operator(result)
                reply = ('İlk adımı hazırladım. Telegram veya panelden inceleyip onaylayabilirsin.'
                         if result.get('token') else str((result.get('task') or {}).get('result', 'Görevi inceledim.')))
            voice_reply['message'] = reply

        voice = VoiceService(store, on_command=voice_command, on_state=voice_state)

    def new_desktop_url():
        now = time.time()
        for key in list(desktop_nonces):
            if desktop_nonces[key] < now:
                desktop_nonces.pop(key, None)
        token = secrets.token_urlsafe(32)
        desktop_nonces[token] = now + 90
        return store.get_settings()['public_url'] + '/desktop/bootstrap?token=' + token

    def emergency_stop():
        if operator:
            operator.stop()
        if voice:
            voice.stop()
        store.update_settings({'paused': True})
        store.invalidate_actions()
        hud.update(state='idle', message='Durduruldu. Devam etmek için panelden duraklatmayı kaldırın.')
        hud_error['message'] = ''

    async def notify_operator(result):
        if not desktop_mode:
            return
        hud_error['message'] = ''
        if result.get('token'):
            hud.update(state='idle', message='Masaüstü adımı onayınızı bekliyor.')
        else:
            hud.update(state='idle', message='Masaüstü görevi tamamlandı veya durduruldu.')
        cfg = store.get_settings()
        if not cfg.get('telegram_bot_token') or not cfg.get('telegram_chat_id'):
            return
        try:
            client = TelegramClient(cfg)
            if result.get('token'):
                critical = result.get('critical', False)
                token = result['token']
                markup = {'inline_keyboard': [[
                    {'text': 'Bu son işlemi onayla' if critical else 'Bu adımı onayla',
                     'callback_data': ('opfinal:' if critical else 'opapprove:') + token},
                    {'text': 'Reddet', 'callback_data': 'opreject:' + token}]]}
                caption = ('MASAÜSTÜ — ' + ('SON İŞLEM ONAYI' if critical else 'ADIM ONAYI') + '\n' +
                           str(result.get('explanation', '')) + '\n' +
                           json.dumps(result.get('action', {}), ensure_ascii=False) +
                           '\nEkran önizlemesini inceleyin. Yalnız bu eylem uygulanacak.')
                image, _, _ = store.read_asset(result['screenshot_asset_id'])
                await client.send_photo(image, caption=caption[:1000],
                                        reply_markup=markup if len(caption) <= 1000 else None)
                if len(caption) > 1000:
                    parts = [caption[n:n + 3900] for n in range(1000, len(caption), 3900)]
                    for index, part in enumerate(parts):
                        await client.send_message(part, reply_markup=markup if index == len(parts) - 1 else None)
            else:
                await client.send_message('Masaüstü görevi: ' + str(result.get('state', 'tamamlandı')))
        except Exception as exc:
            store.add_event('Masaüstü onayı Telegram’a iletilemedi; panelde bekliyor. ' + str(exc), 'warning')

    async def operator_decision(token, decision, actor_chat=None):
        if not operator:
            raise ValueError('Masaüstü sürümü gerekli.')
        hud.update(state='working', message='Onaylanan tek masaüstü adımı uygulanıyor.')
        result = await operator.execute_step(token, decision, actor_chat=actor_chat)
        await notify_operator(result)
        return result

    async def listen_and_reply():
        nonlocal listen_pending
        try:
            voice_reply['message'] = ''
            await voice.listen()
            reply = voice_reply.get('message', '')
            if reply and store.get_settings().get('voice_enabled') and not store.get_settings().get('paused'):
                await voice.speak(reply[:600])
        finally:
            listen_pending = False

    def begin_listen():
        nonlocal listen_pending
        if not voice:
            raise ValueError('Mikrofon masaüstü sürümünde kullanılabilir.')
        cfg = store.get_settings()
        if not cfg.get('microphone_enabled'):
            raise ValueError('Önce ayarlardan mikrofon iznini açın.')
        if not cfg.get('openai_api_key'):
            raise ValueError('Önce OpenAI API anahtarını girin.')
        if listen_pending or voice.status()['busy']:
            raise ValueError('Bir ses işlemi sürüyor; önce durdurun veya tamamlanmasını bekleyin.')
        listen_pending = True
        hud_error['message'] = ''
        launch(listen_and_reply(), 'Sesli komut')

    def callback_uri(provider):
        base = store.get_settings()['public_url']
        if desktop_mode:
            # HTTPS loopback is registered with the provider; its final URL is
            # pasted back into the local application. No TLS warning is bypassed
            # and no third-party callback server receives the authorization code.
            port = urlsplit(base).port or 8080
            return f'https://localhost:{port}/auth/{provider}/callback'
        return base + f'/auth/{provider}/callback'

    def launch(coro, label):
        async def guarded():
            try:
                await coro
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                store.add_event(f'{label}: {exc}', 'error')
                if desktop_mode:
                    hud.update(state='error', message=str(exc)[:160])
                    hud_error['message'] = str(exc)[:160]
        task = asyncio.create_task(guarded())
        tasks.add(task)
        task.add_done_callback(tasks.discard)
        return task

    async def refresh_etsy():
        cfg = store.get_settings()
        if cfg.get('etsy_refresh_token') and float(cfg.get('etsy_token_expires_at', 0)) < time.time() + 300:
            token = await EtsyClient(cfg).refresh_access_token()
            store.update_settings({'etsy_access_token': token['access_token'],
                                   'etsy_refresh_token': token.get('refresh_token', cfg['etsy_refresh_token']),
                                   'etsy_token_expires_at': time.time() + token.get('expires_in', 3600)})

    async def refresh_social_tokens():
        cfg = store.get_settings()
        if (cfg.get('pinterest_refresh_token') and
            float(cfg.get('pinterest_token_expires_at', 0)) < time.time() + 600):
            async with httpx.AsyncClient(timeout=25) as client:
                r = await client.post('https://api.pinterest.com/v5/oauth/token',
                    auth=(cfg.get('pinterest_client_id', ''), cfg.get('pinterest_client_secret', '')),
                    data={'grant_type': 'refresh_token', 'refresh_token': cfg['pinterest_refresh_token']})
            if r.status_code != 200:
                raise ValueError(f'Pinterest bağlantısı yenilenemedi (HTTP {r.status_code}); yeniden bağlayın.')
            token = r.json()
            store.update_settings({'pinterest_access_token': token['access_token'],
                'pinterest_refresh_token': token.get('refresh_token', cfg['pinterest_refresh_token']),
                'pinterest_token_expires_at': time.time() + token.get('expires_in', 2592000)})
        if (cfg.get('instagram_client_id') and cfg.get('instagram_access_token') and
            cfg.get('instagram_token_expires_at') and
            float(cfg['instagram_token_expires_at']) < time.time() + 7 * 86400):
            async with httpx.AsyncClient(timeout=25) as client:
                r = await client.get('https://graph.instagram.com/refresh_access_token',
                    params={'grant_type': 'ig_refresh_token', 'access_token': cfg['instagram_access_token']})
            if r.status_code != 200:
                raise ValueError(f'Instagram bağlantısı yenilenemedi (HTTP {r.status_code}); yeniden bağlayın.')
            token = r.json()
            store.update_settings({'instagram_access_token': token['access_token'],
                'instagram_token_expires_at': time.time() + token.get('expires_in', 5184000)})

    async def telegram_loop():
        while True:
            cfg = store.get_settings()
            if not cfg.get('telegram_bot_token'):
                await asyncio.sleep(3)
                continue
            try:
                client = TelegramClient(cfg)
                # Do not silently delete a pre-existing webhook belonging to another app.
                if not store.get_meta('telegram_polling_checked'):
                    webhook = await client.webhook_info()
                    if webhook.get('url'):
                        raise ValueError('Bu botta webhook var. Jarvis için yeni BotFather botu kullanın.')
                    store.set_meta('telegram_polling_checked', True)
                updates = await client.updates(offset=store.get_meta('telegram_offset', 0), timeout=20)
                for update in updates:
                    store.set_meta('telegram_offset', update['update_id'] + 1)
                    message = update.get('message', {})
                    text = message.get('text', '')
                    chat = message.get('chat', {})
                    sender = message.get('from', {})
                    claim = store.get_meta('telegram_claim')
                    if (claim and claim['expires'] > time.time() and chat.get('type') == 'private'
                        and hmac.compare_digest(text, '/start ' + claim['code'])):
                        store.update_settings({'telegram_chat_id': str(chat['id']),
                                               'telegram_user_id': str(sender['id'])})
                        store.set_meta('telegram_claim', None)
                        await client.send_message('Bağlantı tamamlandı. Kararları yalnız bu özel sohbetten kabul edeceğim. '
                                                  'Sesli özetler yapay zekâ ile üretilir. /status /pause /resume', chat_id=chat['id'])
                        store.add_event('Telegram sahibi güvenli eşleştirmeyle bağlandı.')
                        continue
                    is_owner = (str(sender.get('id', '')) == str(cfg.get('telegram_user_id', cfg.get('telegram_chat_id', 'x')))
                                and str(chat.get('id', '')) == str(cfg.get('telegram_chat_id', 'x')))
                    if is_owner and text in ('/pause', '/durdur'):
                        store.update_settings({'paused': True})
                        store.invalidate_actions()
                        await client.send_message('Yeni işlemler durduruldu. Bekleyen onaylar iptal edildi. Gönderilmiş API çağrısı geri alınamaz.')
                    elif is_owner and text == '/resume':
                        store.update_settings({'paused': False})
                        await client.send_message('Devam edildi. İptal edilmiş onaylar tekrar kullanılmaz; yeni paket başlatabilirsiniz.')
                    elif is_owner and text == '/status':
                        await client.send_message(f"Durum: {'duraklatıldı' if cfg.get('paused') else 'çalışıyor'}. "
                                                  f"Program: {'açık' if cfg.get('scheduling_enabled') else 'kapalı'}. "
                                                  'Ayrıntılar yönetim ekranında.')
                    callback = update.get('callback_query')
                    if callback:
                        callback_chat = callback.get('message', {}).get('chat', {}).get('id')
                        sender_id = callback.get('from', {}).get('id')
                        expected_sender = cfg.get('telegram_user_id') or cfg.get('telegram_chat_id')
                        if (str(sender_id) != str(expected_sender) or
                            str(callback_chat) != str(cfg.get('telegram_chat_id'))):
                            await client.answer_callback(callback['id'], 'Bu işlem için yetkiniz yok.')
                            continue
                        raw = callback.get('data', '')
                        decision, _, token = raw.partition(':')
                        if decision in ('opapprove', 'opfinal', 'opreject') and desktop_mode:
                            mapped = {'opapprove': 'approve', 'opfinal': 'approve_critical', 'opreject': 'reject'}[decision]
                            await client.answer_callback(callback['id'], 'Masaüstü kararınız alındı; yalnız bu adım uygulanacak.')
                            launch(operator_decision(token, mapped, actor_chat=callback_chat), 'Telegram masaüstü onayı')
                            continue
                        if decision not in ('approve', 'reject'):
                            await client.answer_callback(callback['id'], 'Geçersiz karar.')
                            continue
                        await client.answer_callback(callback['id'], 'Karar alındı; sonuç ayrıca bildirilecek.')
                        launch(engine.decide(token, decision, actor_chat=callback_chat), 'Telegram kararı')
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                last = store.get_meta('telegram_last_error', '')
                error = str(exc)
                if last != error:
                    store.add_event('Telegram: ' + error, 'error')
                    store.set_meta('telegram_last_error', error)
                await asyncio.sleep(10)

    async def schedule_loop():
        while True:
            try:
                try:
                    await refresh_etsy()
                except Exception as exc:
                    if time.time() - store.get_meta('etsy_refresh_error_at', 0) > 3600:
                        store.add_event('Etsy bağlantısı yenilenemedi: ' + str(exc), 'warning')
                        store.set_meta('etsy_refresh_error_at', time.time())
                if time.time() - store.get_meta('social_refresh_check', 0) > 3600:
                    store.set_meta('social_refresh_check', time.time())
                    try:
                        await refresh_social_tokens()
                    except Exception as exc:
                        store.add_event('Sosyal bağlantı yenilenemedi: ' + str(exc), 'warning')
                cfg = store.get_settings()
                now = datetime.now(ZoneInfo(cfg['time_zone']))
                key = now.strftime('%Y-%m-%d')
                if (cfg.get('scheduling_enabled') and not cfg.get('paused') and not cfg.get('dry_run')
                    and now.weekday() in (0, 2, 4) and now.hour == int(cfg['hour'])
                    and store.get_meta('last_scheduled_date') != key):
                    store.set_meta('last_scheduled_date', key)
                    active = [c for c in store.list_campaigns() if c['status'] not in
                              ('completed', 'rejected', 'dismissed', 'failed', 'cancelled')]
                    if active:
                        store.add_event('Program saati: önceki paket beklediği için yeni ücretli paket başlatılmadı.')
                    else:
                        launch(engine.run_campaign(), 'Zamanlanmış araştırma')
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                store.add_event('Zamanlayıcı: ' + str(exc), 'error')
            await asyncio.sleep(30)

    async def emergency_loop():
        while True:
            if operator and operator.status().get('is_busy') and operator.emergency_pressed():
                emergency_stop()
                store.add_event('F8 / sol üst köşe acil durdurması uygulandı.', 'warning')
            elif voice and voice.status()['busy'] and os.name == 'nt':
                import ctypes
                if ctypes.windll.user32.GetAsyncKeyState(0x77) & 0x8000:
                    emergency_stop()
            await asyncio.sleep(0.12)

    @asynccontextmanager
    async def lifespan(app):
        for campaign in store.list_campaigns():
            if campaign['status'] == 'processing':
                store.update_campaign(campaign['id'], status='uncertain')
                store.add_event('Yeniden başlatma: yarım kalan iş otomatik tekrarlanmadı. Uzak kayıtları kontrol edin.',
                                'warning', campaign['id'])
        if workers:
            launch(telegram_loop(), 'Telegram işçisi')
            launch(schedule_loop(), 'Zamanlayıcı')
            if desktop_mode:
                launch(emergency_loop(), 'Acil durdurma denetimi')
        yield
        if voice:
            voice.stop()
        if operator:
            operator.stop()
        for task in list(tasks):
            task.cancel()
        if tasks:
            await asyncio.gather(*list(tasks), return_exceptions=True)

    app = FastAPI(title='Jarvis Etsy Asistanı', lifespan=lifespan, docs_url=None, redoc_url=None)
    app.state.store = store
    app.state.engine = engine
    app.state.operator = operator
    app.state.voice = voice

    @app.exception_handler(ValueError)
    async def value_error(request, exc):
        if desktop_mode:
            hud.update(state='error', message=str(exc)[:160])
            hud_error['message'] = str(exc)[:160]
        return JSONResponse({'detail': str(exc)}, status_code=400)

    if desktop_mode:
        from .voice import VoiceError

        @app.exception_handler(VoiceError)
        async def voice_error(request, exc):
            hud.update(state='error', message=str(exc)[:160])
            hud_error['message'] = str(exc)[:160]
            return JSONResponse({'detail': str(exc)}, status_code=400)

    @app.exception_handler(ProviderError)
    async def provider_error(request, exc):
        store.add_event(str(exc), 'error')
        return JSONResponse({'detail': str(exc)}, status_code=502)

    @app.middleware('http')
    async def headers(request, call_next):
        if request.method not in ('GET', 'HEAD', 'OPTIONS'):
            origin = request.headers.get('origin')
            expected = store.get_settings()['public_url']
            actual = str(request.base_url).rstrip('/')
            if origin and origin not in (expected, actual):
                return JSONResponse({'detail': 'İstek kaynağı doğrulanamadı.'}, status_code=403)
        response = await call_next(request)
        response.headers['X-Content-Type-Options'] = 'nosniff'
        response.headers['X-Frame-Options'] = 'DENY'
        response.headers['Referrer-Policy'] = 'no-referrer'
        if request.url.path.startswith('/api') or request.url.path.startswith('/auth'):
            response.headers['Cache-Control'] = 'no-store'
        return response

    def authorized(request, csrf=False):
        session = store.session(request.cookies.get('jarvis_session'))
        if not session:
            raise HTTPException(401, 'Önce giriş yapın.')
        if csrf and not hmac.compare_digest(request.headers.get('x-csrf-token', ''), session['csrf']):
            raise HTTPException(403, 'Güvenlik oturumu yenilenmeli; sayfayı yenileyin.')
        return session

    async def payload(request):
        if int(request.headers.get('content-length', '0') or 0) > 100_000:
            raise HTTPException(413, 'İstek çok büyük.')
        body = bytearray()
        async for chunk in request.stream():
            body.extend(chunk)
            if len(body) > 100_000:
                raise HTTPException(413, 'İstek çok büyük.')
        try:
            data = json.loads(body)
        except (ValueError, UnicodeDecodeError):
            raise HTTPException(400, 'JSON biçimi geçersiz.')
        if not isinstance(data, dict):
            raise HTTPException(400, 'Nesne bekleniyor.')
        return data

    def clean_settings(data):
        if not isinstance(data, dict):
            raise ValueError('Ayarlar nesne olmalı.')
        result = {k: v for k, v in data.items() if k in ALLOWED_SETTINGS}
        for key in SECRET_FIELDS:
            if key in result and not isinstance(result[key], str):
                raise ValueError('API kimlik bilgileri metin olmalı.')
        for key in ('paused', 'scheduling_enabled', 'dry_run', 'operator_enabled', 'microphone_enabled', 'voice_enabled'):
            if key in result and not isinstance(result[key], bool):
                raise ValueError('Program seçenekleri doğru/yanlış olmalı.')
        for key in ('printify_variant_ids', 'production_partner_ids'):
            if isinstance(result.get(key), str):
                try:
                    result[key] = [int(x.strip()) for x in result[key].split(',') if x.strip()]
                except ValueError:
                    raise ValueError('Varyant ve üretim ortağı kimlikleri sayı olmalı.')
        for key in ('hour',):
            if key in result:
                result[key] = int(result[key])
                if not 0 <= result[key] <= 23:
                    raise ValueError('Saat 0–23 arasında olmalı.')
        for key in ('budget_per_run', 'retail_price'):
            if key in result:
                result[key] = float(result[key])
                if not math.isfinite(result[key]) or result[key] <= 0:
                    raise ValueError('Fiyat ve bütçe pozitif olmalı.')
        if 'time_zone' in result:
            try:
                ZoneInfo(result['time_zone'])
            except (ZoneInfoNotFoundError, ValueError):
                raise ValueError('Geçersiz saat dilimi.')
        if (result.get('telegram_bot_token') and
            result['telegram_bot_token'] != store.get_settings().get('telegram_bot_token')):
            store.set_meta('telegram_polling_checked', False)
            store.set_meta('telegram_offset', 0)
            store.set_meta('telegram_claim', None)
            result['telegram_chat_id'] = ''
            result['telegram_user_id'] = ''
            store.invalidate_actions()
        return result

    def session_response(request, extra=None):
        token, csrf = store.new_session()
        response = JSONResponse({'ok': True, 'csrf_token': csrf, **(extra or {})})
        response.set_cookie('jarvis_session', token, httponly=True, samesite='lax',
                            secure=store.get_settings()['public_url'].startswith('https://'), max_age=86400)
        return response

    if desktop_mode:
        def desktop_authorized(request):
            supplied = request.headers.get('x-desktop-token', '')
            if not hmac.compare_digest(supplied, desktop_control['token']):
                raise HTTPException(403, 'Masaüstü oturumu doğrulanamadı.')

        def stop_desktop():
            callback = desktop_control.get('on_stop')
            if callback:
                asyncio.get_running_loop().call_later(0.3, callback)

        @app.get('/desktop/ping')
        async def desktop_ping(request: Request):
            desktop_authorized(request)
            return {'instance': desktop_control['instance']}

        @app.post('/desktop/open')
        async def desktop_open(request: Request):
            desktop_authorized(request)
            return {'url': new_desktop_url()}

        def hud_snapshot():
            result = dict(hud)
            cfg = store.get_settings()
            audio, control = voice.status(), operator.status()
            if audio['state'] in ('listening', 'speaking', 'working', 'error'):
                result.update(state=audio['state'], message=audio['message'])
            elif control['state'] in ('planning', 'executing'):
                result.update(state='working', message='Masaüstü adımı hazırlanıyor / uygulanıyor.')
            elif control['state'] == 'error':
                result.update(state='error', message=str(control.get('error') or 'Masaüstü işlemi durduruldu.'))
            elif control.get('pending'):
                result.update(state='idle', message='Masaüstü adımı onayınızı bekliyor.')
            if hud_error['message']:
                result.update(state='error', message=hud_error['message'])
            result.update(mic_enabled=audio['state'] == 'listening',
                          microphone_permission=bool(cfg.get('microphone_enabled')),
                          operator_enabled=bool(cfg.get('operator_enabled')),
                          busy=bool(audio['busy'] or control.get('is_busy')),
                          paused=bool(cfg.get('paused')))
            return result

        @app.get('/desktop/hud/state')
        async def hud_state(request: Request):
            desktop_authorized(request)
            return hud_snapshot()

        @app.post('/desktop/hud/action')
        async def hud_action(request: Request):
            desktop_authorized(request)
            body = await payload(request)
            action = body.get('action')
            if action == 'settings':
                return {'url': new_desktop_url()}
            if action == 'listen':
                if voice.status()['busy'] or listen_pending:
                    voice.stop()
                else:
                    begin_listen()
            elif action == 'stop':
                emergency_stop()
            elif action == 'mute':
                voice.stop()
            elif action == 'close':
                emergency_stop()
                stop_desktop()
            elif action == 'clear_error':
                voice.stop()
                operator.stop()
                hud.update(state='idle', message='Hazır. Dinlemek için küreye tıklayın.')
                hud_error['message'] = ''
            else:
                raise ValueError('Bilinmeyen masaüstü komutu.')
            return {'ok': True, **hud_snapshot()}

        @app.get('/api/operator/state')
        async def operator_state(request: Request):
            authorized(request)
            return {**operator.status(), 'voice': voice.status(), 'hud': hud_snapshot()}

        @app.post('/api/operator/plan')
        async def operator_plan(request: Request):
            authorized(request, True)
            body = await payload(request)
            if not store.get_settings().get('operator_enabled'):
                raise ValueError('Önce ekran, fare ve klavye erişimini açın.')
            hud.update(state='working', message='Hedef pencereye geçin; ekran üç saniye sonra incelenecek.')
            hud_error['message'] = ''
            await asyncio.sleep(3)
            result = await operator.plan_task(body.get('task', ''))
            await notify_operator(result)
            return result

        @app.post('/api/operator/decision/{token}')
        async def operator_decide_api(token: str, request: Request):
            authorized(request, True)
            body = await payload(request)
            return await operator_decision(token, body.get('decision'))

        @app.post('/api/operator/stop')
        async def operator_stop(request: Request):
            authorized(request, True)
            emergency_stop()
            return {'ok': True, **operator.status()}

        @app.get('/api/operator/screenshot')
        async def operator_screenshot(request: Request):
            authorized(request)
            result = await operator.screenshot()
            return {**result, 'asset_id': result.get('screenshot_asset_id', result.get('asset_id'))}

        @app.post('/api/voice/listen')
        async def voice_listen(request: Request):
            authorized(request, True)
            begin_listen()
            return {'ok': True, 'message': 'Mikrofon kaydı başlatılıyor; en fazla 15 saniye.'}

        @app.post('/api/voice/speak')
        async def voice_speak(request: Request):
            authorized(request, True)
            body = await payload(request)
            if not store.get_settings().get('voice_enabled'):
                raise ValueError('Önce sesli yanıtları etkinleştirin.')
            if voice.status()['busy']:
                raise ValueError('Bir ses işlemi sürüyor.')
            launch(voice.speak(str(body.get('text', 'Merhaba. Ben Jarvis. Onayın olmadan masaüstünde işlem yapmayacağım.'))), 'Masaüstü ses')
            return {'ok': True}

        @app.post('/api/voice/stop')
        async def voice_stop(request: Request):
            authorized(request, True)
            voice.stop()
            return {'ok': True}

        @app.get('/desktop/bootstrap')
        async def desktop_bootstrap(request: Request, token: str):
            expires = desktop_nonces.pop(token, 0)
            if expires < time.time():
                raise HTTPException(403, 'Masaüstü bağlantısının süresi doldu; kısayoldan yeniden açın.')
            session_token, _ = store.new_session()
            response = RedirectResponse('/', status_code=303)
            response.set_cookie('jarvis_session', session_token, httponly=True, samesite='lax', max_age=86400)
            response.headers['Cache-Control'] = 'no-store'
            return response

        @app.post('/desktop/stop')
        async def desktop_stop(request: Request):
            desktop_authorized(request)
            stop_desktop()
            return {'ok': True}

        @app.post('/api/desktop/stop')
        async def desktop_ui_stop(request: Request):
            authorized(request, True)
            stop_desktop()
            return {'ok': True, 'message': 'JARVIS kapatılıyor.'}

        @app.post('/api/desktop/oauth/{provider}/begin')
        async def desktop_oauth_begin(provider: str, request: Request):
            authorized(request, True)
            cfg = store.get_settings()
            if provider not in ('etsy', 'instagram', 'pinterest'):
                raise ValueError('Desteklenmeyen hesap.')
            redirect = callback_uri(provider)
            extra = {'redirect_uri': redirect}
            if provider == 'etsy':
                if not cfg.get('etsy_key'):
                    raise ValueError('Önce Etsy uygulama anahtarını kaydedin.')
                verifier = secrets.token_urlsafe(48)
                extra['verifier'] = verifier
                challenge = base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).decode().rstrip('=')
                params = {'client_id': cfg['etsy_key'], 'response_type': 'code', 'redirect_uri': redirect,
                          'scope': 'listings_r listings_w shops_r', 'code_challenge': challenge,
                          'code_challenge_method': 'S256'}
                url = 'https://www.etsy.com/oauth/connect?'
            elif provider == 'instagram':
                if not cfg.get('instagram_client_id') or not cfg.get('instagram_client_secret'):
                    raise ValueError('Önce Instagram uygulama kimliğini ve gizli anahtarını kaydedin.')
                params = {'client_id': cfg['instagram_client_id'], 'response_type': 'code', 'redirect_uri': redirect,
                          'scope': 'instagram_business_basic,instagram_business_content_publish',
                          'enable_fb_login': '0', 'force_authentication': '1'}
                url = 'https://www.instagram.com/oauth/authorize?'
            else:
                if not cfg.get('pinterest_client_id') or not cfg.get('pinterest_client_secret'):
                    raise ValueError('Önce Pinterest uygulama kimliğini ve gizli anahtarını kaydedin.')
                params = {'client_id': cfg['pinterest_client_id'], 'response_type': 'code', 'redirect_uri': redirect,
                          'scope': 'boards:read,boards:write,pins:read,pins:write,user_accounts:read'}
                url = 'https://www.pinterest.com/oauth/?'
            params['state'] = oauth_state(request, provider, extra)
            return {'authorize_url': url + urlencode(params), 'redirect_uri': redirect,
                    'message': 'Yönlendirme adresini platform uygulamanıza ekleyin. İzin verdikten sonra '
                               'tarayıcıdaki son adresin tamamını buraya yapıştırın. Yerel HTTPS sayfası '
                               'açılmayabilir; sertifika uyarılarını atlamayın. Platform localhost adresini '
                               'kabul etmiyorsa kendi yetkili erişim tokenınızı kullanın.'}

        @app.post('/api/desktop/oauth/{provider}/complete')
        async def desktop_oauth_complete(provider: str, request: Request):
            authorized(request, True)
            body = await payload(request)
            url = urlsplit(str(body.get('callback_url', '')))
            if f'{url.scheme}://{url.netloc}{url.path}' != callback_uri(provider):
                raise ValueError('Yapıştırılan adres bu hesabın yerel geri dönüş adresiyle eşleşmiyor.')
            query = parse_qs(url.query)
            state_value = query.get('state', [''])[0]
            if not state_value:
                raise ValueError('Geri dönüş adresinde güvenlik durumu bulunamadı.')
            if provider == 'etsy':
                await etsy_callback(request, state_value, query.get('code', [''])[0], query.get('error', [''])[0])
            elif provider == 'instagram':
                await instagram_callback(request, state_value, query.get('code', [''])[0], query.get('error', [''])[0])
            elif provider == 'pinterest':
                await pinterest_callback(request, state_value, query.get('code', [''])[0], query.get('error', [''])[0])
            else:
                raise ValueError('Desteklenmeyen hesap.')
            return {'ok': True, 'message': 'Hesap bağlantısı tamamlandı.'}

    @app.get('/healthz')
    async def health():
        with store.db() as c:
            c.execute('SELECT 1').fetchone()
        return {'status': 'ok', 'service': 'jarvis', 'version': '1.0.0'}

    @app.get('/')
    async def index():
        return FileResponse(Path(__file__).parent / 'static' / 'index.html')

    @app.get('/api/state')
    async def state(request: Request):
        session = store.session(request.cookies.get('jarvis_session'))
        if not session:
            return {'authenticated': False, 'configured': bool(store.get_meta('password')), 'desktop': desktop_mode}
        settings, presence = store.public_settings()
        return {'authenticated': True, 'configured': True, 'desktop': desktop_mode, 'settings': settings, 'presence': presence,
                'csrf_token': session['csrf'], 'campaigns': store.list_campaigns(), 'events': store.events(),
                'connections': store.get_meta('connections', {}),
                'operator': operator.status() if operator else None,
                'voice': voice.status() if voice else None,
                'hud': hud_snapshot() if desktop_mode else None,
                'oauth_redirects': {provider: callback_uri(provider) for provider in ('etsy', 'instagram', 'pinterest')}}

    @app.post('/api/login')
    async def login(request: Request):
        key = request.client.host if request.client else 'unknown'
        failures = [t for t in rate_limits.get(key, []) if time.time() - t < 900]
        if len(failures) >= 10:
            raise HTTPException(429, 'Çok fazla deneme. 15 dakika sonra tekrar deneyin.')
        data = await payload(request)
        if not store.check_password(str(data.get('password', ''))):
            rate_limits[key] = failures + [time.time()]
            raise HTTPException(401, 'Parola yanlış.')
        rate_limits.pop(key, None)
        return session_response(request)

    @app.post('/api/setup')
    async def setup(request: Request):
        if store.get_meta('password'):
            raise HTTPException(409, 'Kurulum zaten yapılmış; giriş yapın.')
        expected = os.getenv('JARVIS_SETUP_TOKEN', '')
        if not expected or not hmac.compare_digest(expected, request.headers.get('x-setup-token', '')):
            raise HTTPException(403, 'Dağıtımın JARVIS_SETUP_TOKEN değeri gerekli.')
        data = await payload(request)
        store.set_password(str(data.get('password', '')))
        store.update_settings(clean_settings(data.get('settings', {})))
        return session_response(request)

    @app.post('/api/logout')
    async def logout(request: Request):
        authorized(request, True)
        store.delete_session(request.cookies['jarvis_session'])
        response = JSONResponse({'ok': True})
        response.delete_cookie('jarvis_session')
        return response

    @app.patch('/api/settings')
    async def settings(request: Request):
        authorized(request, True)
        data = await payload(request)
        updates = clean_settings(data.get('settings', {}))
        impact_fields = {'etsy_shop_id','printify_shop_id','retail_price','printify_blueprint_id',
                         'printify_provider_id','printify_variant_ids','etsy_taxonomy_id',
                         'etsy_shipping_profile_id','etsy_readiness_state_id','production_partner_ids',
                         'instagram_account_id','pinterest_board_id','currency','language'}
        old = store.get_settings()
        if any(k in updates and updates[k] != old.get(k) for k in impact_fields):
            store.invalidate_actions()
            store.add_event('Ürün/hesap ayarları değişti; eski onaylar iptal edildi.', 'warning')
        store.update_settings(updates)
        hud_error['message'] = ''
        if operator and updates.get('operator_enabled') is False:
            operator.stop()
        if voice and (updates.get('microphone_enabled') is False or updates.get('voice_enabled') is False):
            voice.stop()
        store.add_event('Ayarlar güvenli depoya kaydedildi.')
        return {'ok': True}

    @app.post('/api/telegram/discover')
    async def discover(request: Request):
        authorized(request, True)
        client = TelegramClient(store.get_settings())
        me = await client.me()
        code = secrets.token_urlsafe(12)
        store.set_meta('telegram_claim', {'code': code, 'expires': time.time() + 600})
        return {'message': 'Bağlantıyı açın ve Başlat’a dokunun. Eşleştirme 10 dakika geçerli.',
                'code': code, 'deep_link': f'https://t.me/{me["username"]}?start={code}'}

    @app.get('/api/connections/check')
    async def connections(request: Request):
        authorized(request)
        cfg = store.get_settings()
        checks = {}
        jobs = []
        async def check(name, operation):
            try:
                result = await operation()
                checks[name] = {'ok': True, 'message': 'API erişimi doğrulandı.', 'result': result}
            except Exception as exc:
                checks[name] = {'ok': False, 'message': str(exc)}
        if cfg.get('telegram_bot_token'):
            jobs.append(check('telegram', TelegramClient(cfg).me))
        if cfg.get('printify_token'):
            async def shops():
                result = await PrintifyClient(cfg).shops()
                if len(result) == 1 and not cfg.get('printify_shop_id'):
                    store.update_settings({'printify_shop_id': str(result[0]['id'])})
                return result
            jobs.append(check('printify', shops))
        if cfg.get('etsy_access_token'):
            jobs.append(check('etsy', EtsyClient(cfg).shop))
        if cfg.get('instagram_access_token'):
            jobs.append(check('instagram', InstagramClient(cfg).profile))
        if cfg.get('pinterest_access_token'):
            jobs.append(check('pinterest', PinterestClient(cfg).profile))
        if cfg.get('openai_api_key'):
            async def models():
                async with httpx.AsyncClient(timeout=20) as client:
                    r = await client.get('https://api.openai.com/v1/models',
                                         headers={'Authorization': 'Bearer ' + cfg['openai_api_key']})
                    if r.status_code != 200:
                        raise ValueError(f'OpenAI erişimi başarısız (HTTP {r.status_code}).')
                return {'message': 'Anahtar çalışıyor; ücretli görsel/ses erişimi ayrı üretimle test edilir.'}
            jobs.append(check('openai', models))
        await asyncio.gather(*jobs)
        # Return account metadata, not entire upstream objects or credential-bearing responses.
        safe = {}
        for name, value in checks.items():
            safe[name] = {'ok': value['ok'], 'message': value['message']}
        store.set_meta('connections', safe)
        return {'connections': safe}

    @app.get('/api/products/catalog')
    async def catalog(request: Request, blueprint_id: int | None = None, provider_id: int | None = None):
        authorized(request)
        client = PrintifyClient(store.get_settings())
        if blueprint_id and provider_id:
            return {'variants': await client.variants(blueprint_id, provider_id)}
        if blueprint_id:
            return {'providers': await client.providers(blueprint_id)}
        return {'shops': await client.shops(), 'blueprints': await client.blueprints()}

    @app.get('/api/etsy/options')
    async def etsy_options(request: Request):
        authorized(request)
        client = EtsyClient(store.get_settings())
        options = await client.get_shop_options()
        options['taxonomy'] = await client.seller_taxonomy()
        return options

    @app.get('/api/pinterest/boards')
    async def pinterest_boards(request: Request):
        authorized(request)
        return await PinterestClient(store.get_settings()).boards()

    @app.post('/api/run')
    async def run(request: Request):
        authorized(request, True)
        body = await payload(request)
        cfg = store.get_settings()
        if cfg.get('paused'):
            raise ValueError('Asistan duraklatılmış.')
        if body.get('dry_run', cfg.get('dry_run', True)):
            store.add_event('DRY_RUN: üretim/yayın yapılmadı; yalnız bağlantıları test edin. Canlı üretim ayrıca başlatılır.')
            if cfg.get('telegram_bot_token') and cfg.get('telegram_chat_id'):
                await TelegramClient(cfg).send_message('Jarvis bağlantı denemesi. Bu işlem tasarım üretmedi veya ürün yayımlamadı.')
            return {'ok': True, 'message': 'Bağlantı denemesi tamamlandı; ücretli üretim ve yayın yapılmadı.'}
        if not cfg.get('openai_api_key'):
            raise ValueError('Önce OpenAI API anahtarını girin.')
        if cfg.get('dry_run', True):
            raise ValueError('Gerçek üretim için Tercihler bölümünde deneme modunu kapatın.')
        if not cfg.get('telegram_bot_token') or not cfg.get('telegram_chat_id'):
            raise ValueError('Önce Telegram botunu güvenli eşleştirmeyle bağlayın.')
        active = [c for c in store.list_campaigns() if c['status'] not in ('completed','rejected','failed','dismissed','cancelled')]
        if active:
            raise ValueError('Önceki paket bekliyor. Tamamlayın veya açıkça kapatın.')
        await refresh_etsy()
        launch(engine.run_campaign(), 'Elle başlatılan araştırma')
        return {'ok': True, 'message': 'Gerçek araştırma kuyruğa alındı; sonuçlar ekranda ve bağlı Telegram’da görünecek.'}

    @app.post('/api/actions/{token}')
    async def action(token: str, request: Request):
        authorized(request, True)
        body = await payload(request)
        if body.get('decision') not in ('approve', 'reject'):
            raise ValueError('Geçersiz karar.')
        action = store.get_action(token)
        if not action or action['status'] != 'pending' or action['expires'] < time.time():
            raise ValueError('Onay kullanılmış veya süresi dolmuş.')
        launch(engine.decide(token, body['decision']), 'Yönetim ekranı kararı')
        return {'ok': True, 'message': 'İşlem başladı; sonuç iş günlüğünde ve Telegram’da görünecek.'}

    @app.post('/api/campaigns/{campaign_id}/dismiss')
    async def dismiss(campaign_id: str, request: Request):
        authorized(request, True)
        campaign = store.get_campaign(campaign_id)
        if campaign['status'] == 'processing':
            raise ValueError('İşlem sürüyor. Önce duraklatın ve tamamlanmasını bekleyin.')
        store.invalidate_actions(campaign_id)
        store.update_campaign(campaign_id, status='dismissed')
        store.add_event('Paket kapatıldı; uzak ürünler kendiliğinden silinmedi.', campaign_id=campaign_id)
        return {'ok': True}

    @app.post('/api/pause')
    async def pause(request: Request):
        authorized(request, True)
        body = await payload(request)
        paused = bool(body.get('paused', True))
        store.update_settings({'paused': paused})
        if paused:
            store.invalidate_actions()
            if operator:
                operator.stop()
            if voice:
                voice.stop()
        return {'ok': True, 'paused': paused}

    @app.post('/api/voice-test')
    async def voice_test(request: Request):
        authorized(request, True)
        cfg = store.get_settings()
        audio = await OpenAIClient(cfg).speech('Merhaba. Ben Jarvis. Araştırma ve tasarımlarını hazırlayacağım. '
                                                'Onayın gelmeden ürün veya sosyal paylaşım yayımlamayacağım.')
        asset_id = store.save_asset(audio, 'audio/mpeg', 'jarvis-ses-testi.mp3')
        if cfg.get('telegram_chat_id') and cfg.get('telegram_bot_token'):
            await TelegramClient(cfg).send_audio(audio, caption='Jarvis ses testi — yapay zekâ sesi')
        return {'ok': True, 'url': '/api/assets/' + asset_id, 'message': 'Ses oluşturuldu.'}

    @app.get('/api/assets/{asset_id}')
    async def asset(asset_id: str, request: Request):
        authorized(request)
        content, mime, filename = store.read_asset(asset_id)
        return Response(content, media_type=mime)

    @app.get('/media/{asset_id}')
    async def media(asset_id: str, expires: int, signature: str):
        if not store.verify_asset(asset_id, expires, signature):
            raise HTTPException(403, 'Dosya bağlantısı geçersiz veya süresi dolmuş.')
        content, mime, _ = store.read_asset(asset_id)
        return Response(content, media_type=mime, headers={'Cache-Control': 'private, max-age=60'})

    def oauth_state(request, provider, extra=None):
        session = authorized(request)
        state = secrets.token_urlsafe(24)
        data = {'provider': provider, 'expires': time.time() + 600, 'session': session['token'], **(extra or {})}
        store.set_meta('oauth:' + state, store.fernet.encrypt(json.dumps(data).encode()).decode())
        return state

    def validate_oauth(request, state, provider):
        session = authorized(request)
        encrypted = store.get_meta('oauth:' + state)
        if not encrypted:
            raise HTTPException(400, 'OAuth bağlantısı geçersiz veya kullanılmış.')
        data = json.loads(store.fernet.decrypt(encrypted.encode()))
        if data['expires'] < time.time() or data['provider'] != provider or data['session'] != session['token']:
            raise HTTPException(400, 'OAuth oturumu doğrulanamadı. Bağlantıyı yeniden başlatın.')
        store.set_meta('oauth:' + state, None)
        return data

    @app.get('/auth/etsy/start')
    async def etsy_start(request: Request):
        cfg = store.get_settings()
        if not cfg.get('etsy_key'):
            raise ValueError('Önce Etsy uygulama anahtarını kaydedin.')
        verifier = secrets.token_urlsafe(48)
        state = oauth_state(request, 'etsy', {'verifier': verifier})
        challenge = base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).decode().rstrip('=')
        params = {'response_type': 'code', 'client_id': cfg['etsy_key'],
                  'redirect_uri': cfg['public_url'] + '/auth/etsy/callback',
                  'scope': 'listings_r listings_w shops_r', 'state': state,
                  'code_challenge': challenge, 'code_challenge_method': 'S256'}
        return RedirectResponse('https://www.etsy.com/oauth/connect?' + urlencode(params))

    @app.get('/auth/etsy/callback')
    async def etsy_callback(request: Request, state: str, code: str = '', error: str = ''):
        data = validate_oauth(request, state, 'etsy')
        if error or not code:
            raise ValueError('Etsy yetkilendirmesi tamamlanmadı. Yeniden bağlayın.')
        cfg = store.get_settings()
        tokens = await EtsyClient(cfg).exchange_code(code, data.get('redirect_uri', cfg['public_url'] + '/auth/etsy/callback'), data['verifier'])
        store.update_settings({'etsy_access_token': tokens['access_token'], 'etsy_refresh_token': tokens['refresh_token'],
                               'etsy_token_expires_at': time.time() + tokens.get('expires_in', 3600)})
        store.invalidate_actions()
        try:
            # Etsy tokens have a documented numerical user-id prefix; discover the shop from that account.
            user_id = tokens['access_token'].split('.')[0]
            if user_id.isdigit():
                shops = await EtsyClient(store.get_settings()).request('GET', f'/users/{user_id}/shops')
                items = shops.get('results', [shops] if shops.get('shop_id') else [])
                if len(items) == 1:
                    store.update_settings({'etsy_shop_id': str(items[0]['shop_id'])})
        except Exception:
            store.add_event('Etsy yetkilendirildi. Mağaza kimliği otomatik okunamadı; ayarlarda tamamlayın.', 'warning')
        store.add_event('Etsy OAuth bağlantısı tamamlandı.')
        return RedirectResponse('/?connected=etsy')

    @app.get('/auth/pinterest/start')
    async def pinterest_start(request: Request):
        cfg = store.get_settings()
        if not cfg.get('pinterest_client_id'):
            raise ValueError('Pinterest uygulama kimliğini önce kaydedin.')
        state = oauth_state(request, 'pinterest')
        params = {'response_type': 'code', 'client_id': cfg['pinterest_client_id'],
                  'redirect_uri': cfg['public_url'] + '/auth/pinterest/callback',
                  'scope': 'boards:read,boards:write,pins:read,pins:write,user_accounts:read', 'state': state}
        return RedirectResponse('https://www.pinterest.com/oauth/?' + urlencode(params))

    @app.get('/auth/instagram/start')
    async def instagram_start(request: Request):
        cfg = store.get_settings()
        if not cfg.get('instagram_client_id'):
            raise ValueError('Önce Instagram uygulama kimliğini kaydedin.')
        state = oauth_state(request, 'instagram')
        params = {'client_id': cfg['instagram_client_id'], 'response_type': 'code',
                  'redirect_uri': cfg['public_url'] + '/auth/instagram/callback',
                  'scope': 'instagram_business_basic,instagram_business_content_publish',
                  'state': state, 'enable_fb_login': '0', 'force_authentication': '1'}
        return RedirectResponse('https://www.instagram.com/oauth/authorize?' + urlencode(params))

    @app.get('/auth/instagram/callback')
    async def instagram_callback(request: Request, state: str, code: str = '', error: str = ''):
        data = validate_oauth(request, state, 'instagram')
        if error or not code:
            raise ValueError('Instagram yetkilendirmesi tamamlanmadı.')
        cfg = store.get_settings()
        async with httpx.AsyncClient(timeout=25) as client:
            r = await client.post('https://api.instagram.com/oauth/access_token',
                data={'client_id': cfg.get('instagram_client_id',''),
                      'client_secret': cfg.get('instagram_client_secret',''),
                      'grant_type': 'authorization_code', 'redirect_uri': data.get('redirect_uri', cfg['public_url'] + '/auth/instagram/callback'),
                      'code': code})
            if r.status_code != 200:
                raise ValueError(f'Instagram token işlemi başarısız (HTTP {r.status_code}).')
            short = r.json()
            r = await client.get('https://graph.instagram.com/access_token',
                params={'grant_type': 'ig_exchange_token', 'client_secret': cfg.get('instagram_client_secret',''),
                        'access_token': short['access_token']})
            if r.status_code != 200:
                raise ValueError(f'Instagram uzun süreli token alınamadı (HTTP {r.status_code}).')
            token = r.json()
        store.update_settings({'instagram_access_token': token['access_token'],
            'instagram_account_id': str(short['user_id']), 'instagram_login_type': 'instagram',
            'instagram_token_expires_at': time.time() + token.get('expires_in', 5184000)})
        store.invalidate_actions()
        store.add_event('Instagram OAuth bağlantısı tamamlandı.')
        return RedirectResponse('/?connected=instagram')

    @app.get('/auth/pinterest/callback')
    async def pinterest_callback(request: Request, state: str, code: str = '', error: str = ''):
        data = validate_oauth(request, state, 'pinterest')
        if error or not code:
            raise ValueError('Pinterest yetkilendirmesi tamamlanmadı.')
        cfg = store.get_settings()
        async with httpx.AsyncClient(timeout=25) as client:
            r = await client.post('https://api.pinterest.com/v5/oauth/token',
                    auth=(cfg.get('pinterest_client_id', ''), cfg.get('pinterest_client_secret', '')),
                    data={'grant_type': 'authorization_code', 'code': code,
                          'redirect_uri': data.get('redirect_uri', cfg['public_url'] + '/auth/pinterest/callback')})
        if r.status_code != 200:
            raise ValueError(f'Pinterest token işlemi başarısız (HTTP {r.status_code}).')
        token = r.json()
        store.update_settings({'pinterest_access_token': token['access_token'],
                               'pinterest_refresh_token': token.get('refresh_token', ''),
                               'pinterest_token_expires_at': time.time() + token.get('expires_in', 0)})
        store.invalidate_actions()
        store.add_event('Pinterest OAuth bağlantısı tamamlandı.')
        return RedirectResponse('/?connected=pinterest')

    return app


app = create_app()
