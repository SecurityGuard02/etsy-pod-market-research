"""Per-user desktop launcher, single instance and authenticated graceful stop.

Windows entry points:
    pythonw.exe -m jarvis.desktop
    pythonw.exe -m jarvis.desktop --stop

The HTTP server binds only 127.0.0.1. Runtime credentials stay in the user's
local application-data directory and are never passed in browser URLs.
"""
from __future__ import annotations

import argparse
from dataclasses import dataclass
import json
import logging
from logging.handlers import RotatingFileHandler
import os
from pathlib import Path
import secrets
import socket
import subprocess
import sys
import threading
import time
from urllib.error import HTTPError, URLError
from urllib.parse import parse_qs, urlsplit
from urllib.request import HTTPRedirectHandler, ProxyHandler, Request, build_opener
import uuid
import webbrowser


LOGGER = logging.getLogger("jarvis.desktop")


class DesktopError(RuntimeError):
    """A user-facing diagnostic that contains no runtime credentials."""


@dataclass(frozen=True)
class Paths:
    root: Path

    @property
    def data(self):
        return self.root / "data"

    @property
    def logs(self):
        return self.root / "logs"

    @property
    def state(self):
        return self.root / "runtime.json"

    @property
    def lock(self):
        return self.root / "instance.lock"

    @property
    def config(self):
        return self.root / "desktop.json"

    def prepare(self):
        for directory in (self.root, self.data, self.logs):
            directory.mkdir(parents=True, exist_ok=True)
            if os.name != "nt":
                directory.chmod(0o700)


def application_paths(override: str | Path | None = None) -> Paths:
    if override:
        return Paths(Path(override).expanduser().resolve())
    if os.getenv("JARVIS_DESKTOP_HOME"):
        return Paths(Path(os.environ["JARVIS_DESKTOP_HOME"]).expanduser().resolve())
    if os.name == "nt":
        local = os.getenv("LOCALAPPDATA")
        if not local:
            raise DesktopError("Windows yerel uygulama klasörü bulunamadı (LOCALAPPDATA).")
        return Paths(Path(local) / "JarvisEtsy")
    return Paths(Path(os.getenv("XDG_DATA_HOME", str(Path.home() / ".local" / "share"))) / "JarvisEtsy")


class InstanceLock:
    """OS-owned file lock; crashes release it without stale PID decisions."""

    def __init__(self, path: Path):
        self.path = path
        self.file = None

    def acquire(self) -> bool:
        handle = self.path.open("a+b")
        if os.name != "nt":
            self.path.chmod(0o600)
        handle.seek(0, 2)
        if handle.tell() == 0:
            handle.write(b"\0")
            handle.flush()
        handle.seek(0)
        try:
            if os.name == "nt":
                import msvcrt
                msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            handle.close()
            return False
        self.file = handle
        return True

    def release(self):
        if self.file is None:
            return
        try:
            self.file.seek(0)
            if os.name == "nt":
                import msvcrt
                msvcrt.locking(self.file.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                import fcntl
                fcntl.flock(self.file.fileno(), fcntl.LOCK_UN)
        finally:
            self.file.close()
            self.file = None


def read_state(paths: Paths) -> dict | None:
    try:
        if paths.state.stat().st_size > 8192:
            return None
        state = json.loads(paths.state.read_text(encoding="utf-8"))
        if not isinstance(state, dict):
            return None
        port = state.get("port")
        if type(port) is not int or not 1 <= port <= 65535:
            return None
        if not isinstance(state.get("control_token"), str) or len(state["control_token"]) < 32:
            return None
        if not isinstance(state.get("instance"), str) or len(state["instance"]) != 32:
            return None
        if type(state.get("pid")) is not int or state["pid"] < 1:
            return None
        return state
    except (OSError, ValueError, UnicodeError):
        return None


def write_state(paths: Paths, state: dict):
    temporary = paths.root / (".runtime-" + secrets.token_hex(8) + ".tmp")
    try:
        descriptor = os.open(temporary, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
            json.dump(state, handle)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, paths.state)
        if os.name != "nt":
            paths.state.chmod(0o600)
    finally:
        temporary.unlink(missing_ok=True)


def remove_own_state(paths: Paths, instance: str):
    state = read_state(paths)
    if state and state["instance"] == instance:
        paths.state.unlink(missing_ok=True)


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def control_request(state: dict, method: str, path: str, timeout: float = 1.5) -> dict:
    if (method, path) not in {("GET", "/desktop/ping"), ("POST", "/desktop/open"), ("POST", "/desktop/stop")}:
        raise ValueError("Unsupported desktop-control operation")
    # Ignore machine HTTP proxies and forbid redirects: the control credential
    # is valid only for this exact loopback server.
    opener = build_opener(ProxyHandler({}), NoRedirect())
    request = Request(f"http://127.0.0.1:{int(state['port'])}{path}",
                      data=b"{}" if method == "POST" else None, method=method,
                      headers={"X-Desktop-Token": state["control_token"], "Content-Type": "application/json"})
    with opener.open(request, timeout=timeout) as response:
        raw = response.read(16385)
        if len(raw) > 16384:
            raise ValueError("Oversized local control response")
    result = json.loads(raw)
    if not isinstance(result, dict):
        raise ValueError("Invalid local control response")
    return result


def alive(state: dict | None) -> bool:
    if not state:
        return False
    try:
        return control_request(state, "GET", "/desktop/ping")["instance"] == state["instance"]
    except (OSError, ValueError, KeyError, HTTPError, URLError):
        return False


def wait_for_instance(paths: Paths, timeout: float = 25) -> dict | None:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        state = read_state(paths)
        if alive(state):
            return state
        time.sleep(0.2)
    return None


def validate_browser_url(url: str, state: dict) -> str:
    try:
        parsed = urlsplit(url)
        query = parse_qs(parsed.query, strict_parsing=True)
        if (parsed.scheme != "http" or parsed.hostname != "127.0.0.1" or parsed.port != state["port"]
                or parsed.username or parsed.password or parsed.path != "/desktop/bootstrap" or parsed.fragment
                or set(query) != {"token"} or len(query["token"]) != 1 or len(query["token"][0]) < 20):
            raise ValueError("Invalid bootstrap location")
    except (TypeError, ValueError, KeyError):
        raise DesktopError("JARVIS güvenli başlangıç adresi doğrulanamadı.") from None
    return url


def open_window(url: str):
    if os.name == "nt":
        candidates = []
        for root in (os.getenv("PROGRAMFILES"), os.getenv("PROGRAMFILES(X86)"), os.getenv("LOCALAPPDATA")):
            if root:
                candidates.extend([Path(root) / "Microsoft" / "Edge" / "Application" / "msedge.exe",
                                   Path(root) / "Google" / "Chrome" / "Application" / "chrome.exe"])
        for executable in candidates:
            if executable.is_file():
                try:
                    subprocess.Popen([str(executable), "--no-first-run", "--app=" + url],
                                     close_fds=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                    return
                except OSError:
                    continue
    if not webbrowser.open(url, new=1):
        raise DesktopError("Tarayıcı açılamadı. JARVIS'i yeniden başlatarak tekrar deneyin.")


def open_existing(state: dict, paths: Paths | None = None, *, settings: bool = False):
    if os.name == 'nt' and not settings:
        profile = paths or application_paths()
        # Reopening raises the existing per-user native orb instead of a panel.
        subprocess.Popen([sys.executable, '-m', 'jarvis.overlay', '--state-dir', str(profile.root)],
                         close_fds=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                         creationflags=subprocess.CREATE_NO_WINDOW)
        return
    try:
        response = control_request(state, "POST", "/desktop/open")
        url = validate_browser_url(response.get("url", ""), state)
    except (OSError, ValueError, HTTPError, URLError):
        raise DesktopError("Çalışan JARVIS penceresi açılamadı; tekrar başlatmayı deneyin.") from None
    open_window(url)


def configure_logging(paths: Paths):
    log = paths.logs / "desktop.log"
    handler = RotatingFileHandler(log, maxBytes=2_000_000, backupCount=3, encoding="utf-8")
    if os.name != "nt":
        log.chmod(0o600)
    handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
    for name in ("jarvis.desktop", "uvicorn.error"):
        logger = logging.getLogger(name)
        for old in logger.handlers:
            old.close()
        logger.handlers.clear()
        logger.addHandler(handler)
        logger.setLevel(logging.INFO)
        logger.propagate = False


def bind_loopback(paths: Paths) -> socket.socket:
    saved_port = None
    if paths.config.exists():
        try:
            if paths.config.stat().st_size > 2048:
                raise ValueError("oversized config")
            saved_port = json.loads(paths.config.read_text(encoding="utf-8"))["port"]
            if type(saved_port) is not int or not 1024 <= saved_port <= 65535:
                raise ValueError("invalid port")
        except (OSError, ValueError, KeyError, TypeError):
            raise DesktopError("Yerel port ayarı okunamadı: desktop.json. Kullanıcı verileri değiştirilmedi.") from None
    # OAuth applications register this loopback port once. Preserve it across
    # restarts and fail visibly if a different program later occupies it.
    candidates = [saved_port] if saved_port else range(8765, 8785)
    for port in candidates:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            if os.name == "nt" and hasattr(socket, "SO_EXCLUSIVEADDRUSE"):
                sock.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
            elif os.name != "nt":
                # POSIX permits a listener to restart while old accepted
                # connections remain in TIME_WAIT; it still forbids a second
                # live listener on the same address without SO_REUSEPORT.
                sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            sock.bind(("127.0.0.1", port))
            sock.listen(128)
            sock.setblocking(False)
        except OSError:
            sock.close()
            if saved_port:
                raise DesktopError(f"JARVIS'in kayıtlı yerel portu ({saved_port}) kullanılamıyor. "
                                   "Bu portu kullanan uygulamayı kapatıp tekrar deneyin.") from None
            continue
        if not saved_port:
            temporary = paths.root / (".desktop-" + secrets.token_hex(8) + ".tmp")
            try:
                descriptor = os.open(temporary, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
                with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
                    json.dump({"port": port}, handle)
                    handle.flush()
                    os.fsync(handle.fileno())
                os.replace(temporary, paths.config)
            except BaseException:
                sock.close()
                raise
            finally:
                temporary.unlink(missing_ok=True)
        return sock
    raise DesktopError("JARVIS için kullanılabilir yerel port bulunamadı (8765–8784).")


def serve(paths: Paths, *, browser: bool = True, settings: bool = False):
    sock = bind_loopback(paths)
    port = sock.getsockname()[1]
    instance = uuid.uuid4().hex
    state = {"port": port, "control_token": secrets.token_urlsafe(48), "pid": os.getpid(), "instance": instance}
    os.environ["JARVIS_DESKTOP"] = "1"
    os.environ["JARVIS_DATA_DIR"] = str(paths.data)
    os.environ["APP_PUBLIC_URL"] = f"http://127.0.0.1:{port}"
    os.environ.setdefault("APP_PASSWORD", secrets.token_urlsafe(48))
    # Import only after configuring the per-user store; app.py also exposes a
    # cloud ASGI entry point whose import must not initialize another directory.
    from .app import create_app
    import uvicorn

    holder = {}
    def on_stop():
        server = holder.get("server")
        if server:
            server.should_exit = True

    app = create_app(data_dir=paths.data, desktop_control={"token": state["control_token"],
                     "instance": instance, "on_stop": on_stop})
    config = uvicorn.Config(app, host="127.0.0.1", port=port, access_log=False,
                            log_config=None, log_level="warning", timeout_graceful_shutdown=12)
    server = uvicorn.Server(config)
    holder["server"] = server
    write_state(paths, state)
    ready_done = threading.Event()
    startup_errors = []

    def wait_then_open():
        try:
            active = wait_for_instance(paths, timeout=30)
            if not active or active["instance"] != instance:
                raise DesktopError("JARVIS zamanında başlayamadı. logs klasöründeki desktop.log dosyasını kontrol edin.")
            if browser:
                open_existing(active, paths, settings=settings)
        except Exception as exc:
            # Exception text from urllib may include a bootstrap nonce. Only
            # our controlled DesktopError messages may be shown or logged.
            message = str(exc) if isinstance(exc, DesktopError) else "JARVIS başlangıç penceresi açılamadı."
            startup_errors.append(message)
            LOGGER.error("%s", message)
            server.should_exit = True
        finally:
            ready_done.set()

    opener_thread = threading.Thread(target=wait_then_open, name="jarvis-desktop-startup", daemon=True)
    opener_thread.start()
    LOGGER.info("Yerel masaüstü sunucusu başlatılıyor (pid=%s).", os.getpid())
    try:
        server.run(sockets=[sock])
    finally:
        remove_own_state(paths, instance)
        sock.close()
        LOGGER.info("Yerel masaüstü sunucusu kapatıldı; kullanıcı verileri korundu.")
    if startup_errors:
        raise DesktopError(startup_errors[0])


def _wait_shutdown_locks(paths: Paths, timeout: float = 15):
    """An update must wait for the owned server and native HUD to release DLLs."""
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        released = True
        for file in (paths.lock, paths.root / 'overlay.lock'):
            if not file.exists():
                continue
            probe = InstanceLock(file)
            acquired = probe.acquire()
            probe.release()
            released = released and acquired
        if released:
            return
        time.sleep(0.1)
    raise DesktopError('JARVIS veya küre henüz kapanmadı. Güncellemeden önce süren işlemin bitmesini bekleyin.')


def stop(paths: Paths) -> bool:
    state = read_state(paths)
    if not alive(state):
        # A held OS lock may mean startup is still in progress. Never kill a
        # process based on a recycled PID from a stale metadata file.
        probe = InstanceLock(paths.lock)
        acquired = probe.acquire()
        probe.release()
        if acquired:
            _wait_shutdown_locks(paths)
            return False
        state = wait_for_instance(paths, timeout=15)
        if not state:
            raise DesktopError("JARVIS henüz yanıt vermiyor. Kısa süre sonra DURDUR'u yeniden çalıştırın.")
    try:
        control_request(state, "POST", "/desktop/stop")
    except (OSError, ValueError, HTTPError, URLError):
        raise DesktopError("JARVIS durdurma isteğini alamadı; tekrar deneyin.") from None
    deadline = time.monotonic() + 15
    while time.monotonic() < deadline:
        if not alive(state):
            _wait_shutdown_locks(paths)
            return True
        time.sleep(0.2)
    raise DesktopError("JARVIS kapanışı tamamlanmadı. Açık işlerin bitmesini bekleyip tekrar deneyin.")


def launch(paths: Paths, *, browser: bool = True, settings: bool = False):
    state = read_state(paths)
    if alive(state):
        if browser:
            open_existing(state, paths, settings=settings)
        return
    lock = InstanceLock(paths.lock)
    if not lock.acquire():
        state = wait_for_instance(paths)
        if not state:
            raise DesktopError("Başka bir JARVIS başlatılıyor veya yanıt vermiyor. Biraz sonra tekrar deneyin.")
        if browser:
            open_existing(state, paths, settings=settings)
        return
    try:
        # Another launch may have completed between our first check and lock.
        state = read_state(paths)
        if alive(state):
            if browser:
                open_existing(state, paths, settings=settings)
            return
        # Exclusive ownership plus failed authenticated ping permits replacing
        # stale runtime metadata. Application data is never cleared.
        serve(paths, browser=browser, settings=settings)
    finally:
        lock.release()


def report_error(message: str):
    if os.name == "nt":
        try:
            import ctypes
            ctypes.windll.user32.MessageBoxW(None, message, "JARVIS Etsy", 0x10)
            return
        except (AttributeError, OSError):
            pass
    if sys.stderr is not None:
        print(message, file=sys.stderr)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="JARVIS Etsy masaüstü başlatıcısı")
    parser.add_argument("--stop", action="store_true", help="Yalnız bu kullanıcıya ait JARVIS'i güvenli biçimde durdur")
    parser.add_argument("--serve", action="store_true", help=argparse.SUPPRESS)
    parser.add_argument("--no-browser", action="store_true", help=argparse.SUPPRESS)
    parser.add_argument("--state-dir", help=argparse.SUPPRESS)
    parser.add_argument("--settings", action="store_true", help="Şeffaf küre yerine ayarlar panelini aç")
    args = parser.parse_args(argv)
    try:
        paths = application_paths(args.state_dir)
        paths.prepare()
        configure_logging(paths)
        if args.stop:
            stop(paths)
        else:
            launch(paths, browser=not (args.serve or args.no_browser), settings=args.settings)
        return 0
    except KeyboardInterrupt:
        return 0
    except Exception as exc:
        message = str(exc) if isinstance(exc, DesktopError) else (
            "JARVIS açılamadı. logs klasöründeki desktop.log dosyasını kontrol edin (" + type(exc).__name__ + ").")
        LOGGER.error("%s", message)
        report_error(message)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
