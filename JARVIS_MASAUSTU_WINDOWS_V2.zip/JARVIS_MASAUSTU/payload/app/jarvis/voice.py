"""Explicit, bounded microphone capture and local speaker output on Windows.

No background listening starts here. A user must enable ``microphone_enabled``
and explicitly request ``listen``. Audio stays in memory and is sent only to
OpenAI for transcription; neither recordings nor transcripts enter the event
log. The caller is responsible for reviewing/approving desktop actions.

Native APIs are loaded lazily so the application and tests remain importable
on cloud/Linux hosts. Inject recorder/player adapters to test without hardware.
"""
from __future__ import annotations

import array
import asyncio
import ctypes
import inspect
import io
import math
import os
import threading
import time
import wave
from typing import Callable

from .providers import OpenAIClient, ProviderError, setting


class VoiceError(RuntimeError):
    pass


# Use fixed-width Windows ABI types; ctypes.c_ulong is 64-bit on Linux.
WORD = ctypes.c_uint16
DWORD = ctypes.c_uint32
UINT = ctypes.c_uint32
HANDLE = ctypes.c_void_p
DWORD_PTR = ctypes.c_size_t


class WAVEFORMATEX(ctypes.Structure):
    _pack_ = 2
    _fields_ = [('wFormatTag', WORD), ('nChannels', WORD),
                ('nSamplesPerSec', DWORD), ('nAvgBytesPerSec', DWORD),
                ('nBlockAlign', WORD), ('wBitsPerSample', WORD), ('cbSize', WORD)]


class WAVEHDR(ctypes.Structure):
    _fields_ = [('lpData', ctypes.c_void_p), ('dwBufferLength', DWORD),
                ('dwBytesRecorded', DWORD), ('dwUser', DWORD_PTR),
                ('dwFlags', DWORD), ('dwLoops', DWORD),
                ('lpNext', ctypes.c_void_p), ('reserved', DWORD_PTR)]


def _winmm():
    if os.name != 'nt':
        raise VoiceError('Yerel mikrofon ve hoparlör Windows masaüstünde çalışır.')
    dll = ctypes.WinDLL('winmm', use_last_error=True)
    dll.waveInGetNumDevs.argtypes = []
    dll.waveInGetNumDevs.restype = UINT
    dll.waveInOpen.argtypes = [ctypes.POINTER(HANDLE), UINT,
                              ctypes.POINTER(WAVEFORMATEX), DWORD_PTR, DWORD_PTR, DWORD]
    dll.waveInOpen.restype = UINT
    for name in ('waveInPrepareHeader', 'waveInUnprepareHeader', 'waveInAddBuffer'):
        fn = getattr(dll, name)
        fn.argtypes = [HANDLE, ctypes.POINTER(WAVEHDR), UINT]
        fn.restype = UINT
    for name in ('waveInStart', 'waveInStop', 'waveInReset', 'waveInClose'):
        fn = getattr(dll, name)
        fn.argtypes = [HANDLE]
        fn.restype = UINT
    dll.PlaySoundW.argtypes = [ctypes.c_void_p, HANDLE, DWORD]
    dll.PlaySoundW.restype = ctypes.c_int
    return dll


def _check_mm(code, operation):
    if code:
        raise VoiceError(f'{operation} başarısız (Windows ses kodu {int(code)}). '
                         'Windows mikrofon izinlerini ve varsayılan ses aygıtını kontrol edin.')


def _pcm_rms(data: bytes) -> float:
    if not data:
        return 0.0
    samples = array.array('h')
    samples.frombytes(data[:len(data) & ~1])
    return math.sqrt(sum(sample * sample for sample in samples) / max(len(samples), 1))


def _wav(pcm: bytes) -> bytes:
    output = io.BytesIO()
    with wave.open(output, 'wb') as wav:
        wav.setnchannels(1)
        wav.setsampwidth(2)
        wav.setframerate(16000)
        wav.writeframes(pcm)
    return output.getvalue()


class WindowsRecorder:
    """WinMM capture with six pinned 100 ms buffers and no device callback.

    Recording ends after the requested duration, an explicit stop, or 1.4 s of
    quiet after speech. Polling avoids native callbacks into the Python runtime.
    All headers and backing buffers survive until reset/unprepare/close finish.
    """
    def record(self, stop_event: threading.Event, seconds: float = 10) -> bytes:
        if stop_event.is_set():
            return _wav(b'')
        dll = _winmm()
        if dll.waveInGetNumDevs() == 0:
            raise VoiceError('Mikrofon bulunamadı. Windows ses giriş aygıtını kontrol edin.')
        duration = max(2.0, min(float(seconds), 15.0))
        fmt = WAVEFORMATEX(1, 1, 16000, 32000, 2, 16, 0)
        handle = HANDLE()
        _check_mm(dll.waveInOpen(ctypes.byref(handle), UINT(0xFFFFFFFF),
                                ctypes.byref(fmt), 0, 0, 0), 'Mikrofon açma')
        prepared = []
        chunks = []
        try:
            for _ in range(6):
                buffer = ctypes.create_string_buffer(3200)
                header = WAVEHDR()
                header.lpData = ctypes.cast(buffer, ctypes.c_void_p)
                header.dwBufferLength = len(buffer)
                _check_mm(dll.waveInPrepareHeader(handle, ctypes.byref(header), ctypes.sizeof(header)),
                          'Ses tamponu hazırlama')
                # Keep the buffer alive alongside its header until device close.
                prepared.append((header, buffer))
                _check_mm(dll.waveInAddBuffer(handle, ctypes.byref(header), ctypes.sizeof(header)),
                          'Ses tamponu ekleme')
            _check_mm(dll.waveInStart(handle), 'Mikrofon kaydı')
            started = time.monotonic()
            heard_speech = False
            quiet_since = None
            next_buffer = 0
            while not stop_event.is_set() and time.monotonic() - started < duration:
                # Preserve capture order even if the scheduler wakes after a
                # buffer-ring wrap. Header index order alone can reorder speech.
                for _ in range(len(prepared)):
                    header, buffer = prepared[next_buffer]
                    if not header.dwFlags & 1:  # WHDR_DONE
                        break
                    count = min(int(header.dwBytesRecorded), len(buffer)) & ~1
                    if count:
                        chunk = bytes(buffer.raw[:count])
                        chunks.append(chunk)
                        if _pcm_rms(chunk) >= 300:
                            heard_speech = True
                            quiet_since = None
                        elif heard_speech and quiet_since is None:
                            quiet_since = time.monotonic()
                    header.dwBytesRecorded = 0
                    _check_mm(dll.waveInAddBuffer(handle, ctypes.byref(header), ctypes.sizeof(header)),
                              'Ses tamponu yenileme')
                    next_buffer = (next_buffer + 1) % len(prepared)
                if (heard_speech and quiet_since is not None
                        and time.monotonic() - quiet_since >= 1.4
                        and time.monotonic() - started >= 2):
                    break
                stop_event.wait(0.02)
            # Reset returns even partial buffers before their storage is freed.
            _check_mm(dll.waveInReset(handle), 'Mikrofon durdurma')
            for index in range(len(prepared)):
                header, buffer = prepared[(next_buffer + index) % len(prepared)]
                count = min(int(header.dwBytesRecorded), len(buffer)) & ~1
                if count and header.dwFlags & 1:
                    chunks.append(bytes(buffer.raw[:count]))
        finally:
            # Also runs after prepare/start/poll errors; reset removes all buffers.
            dll.waveInReset(handle)
            for header, _ in prepared:
                dll.waveInUnprepareHeader(handle, ctypes.byref(header), ctypes.sizeof(header))
            dll.waveInClose(handle)
        pcm = b''.join(chunks)[:int(duration * 32000)]
        if not pcm and not stop_event.is_set():
            raise VoiceError('Mikrofon ses verisi döndürmedi.')
        return _wav(pcm)


class WindowsPlayer:
    def __init__(self):
        self._dll = None

    def play(self, audio: bytes, stop_event: threading.Event):
        if stop_event.is_set():
            return
        dll = self._dll = _winmm()
        buffer = ctypes.create_string_buffer(audio)
        if stop_event.is_set():
            return
        # SND_MEMORY | SND_NODEFAULT; synchronous playback pins buffer lifetime.
        if not dll.PlaySoundW(ctypes.cast(buffer, ctypes.c_void_p), None, 0x0004 | 0x0002):
            if not stop_event.is_set():
                raise VoiceError('Hoparlörde ses çalınamadı. Varsayılan Windows ses çıkışını kontrol edin.')

    def stop(self):
        if self._dll is not None:
            self._dll.PlaySoundW(None, None, 0)


def _validate_wav(audio: bytes):
    if not isinstance(audio, bytes) or not audio.startswith(b'RIFF') or audio[8:12] != b'WAVE':
        raise VoiceError('Ses sağlayıcısı geçerli WAV sesi döndürmedi.')
    try:
        with wave.open(io.BytesIO(audio), 'rb') as source:
            if source.getnframes() <= 0 or source.getnchannels() not in (1, 2):
                raise VoiceError('Ses kaydı boş veya desteklenmeyen kanallar içeriyor.')
    except (wave.Error, EOFError) as exc:
        raise VoiceError('Ses kaydı okunamadı.') from exc


class VoiceService:
    """One explicit voice operation at a time; callbacks never run in audio threads.

    ``on_state(state, message)`` is synchronous. ``on_command(transcript)`` may be
    asynchronous. The command callback must keep the normal desktop approval
    workflow; a transcription is never a publication/action approval.
    """
    def __init__(self, store, on_command: Callable | None = None,
                 on_state: Callable | None = None, *, recorder=None, player=None):
        self.store = store
        self.on_command = on_command
        self.on_state = on_state
        self.recorder = recorder or WindowsRecorder()
        self.player = player or WindowsPlayer()
        self._operation = asyncio.Lock()
        self._stop_event = threading.Event()
        self._state = 'idle'
        self._message = 'Hazır. Dinlemek için mikrofon düğmesine basın.'

    def status(self):
        return {'state': self._state, 'message': self._message,
                'busy': self._operation.locked(),
                'microphone_enabled': self.store.get_settings().get('microphone_enabled') is True,
                'windows_supported': os.name == 'nt'}

    def _set_state(self, state, message):
        self._state, self._message = state, message
        if self.on_state:
            self.on_state(state, message)

    def stop(self):
        self._stop_event.set()
        self.player.stop()
        self._set_state('idle', 'Ses işlemi durduruldu. Dinleme kapalı.')

    def _begin(self):
        if self._operation.locked():
            raise VoiceError('Bir ses işlemi sürüyor. Önce durdurun veya bitmesini bekleyin.')
        config = self.store.get_settings()
        if not setting(config, 'openai_api_key'):
            raise VoiceError('Ses tanıma ve konuşma için ayarlara OpenAI API anahtarını ekleyin.')
        self._stop_event = threading.Event()
        return config, self._stop_event

    async def listen(self, seconds: float = 10) -> str:
        # Check consent before accessing either a device or a cloud provider.
        if self.store.get_settings().get('microphone_enabled') is not True:
            raise VoiceError('Önce ayarlardan mikrofon iznini açın. Dinleme yalnız düğmeye basınca başlar.')
        config, stopped = self._begin()
        async with self._operation:
            try:
                self._set_state('listening', 'Dinliyorum. Kaydı bitirmek için durdurabilirsiniz.')
                audio = await asyncio.to_thread(self.recorder.record, stopped, seconds)
                if stopped.is_set():
                    return ''
                _validate_wav(audio)
                self._set_state('working', 'Sesiniz Türkçe metne dönüştürülüyor…')
                client = OpenAIClient(config)
                result = await client.http.request(
                    'POST', client.base + '/audio/transcriptions', headers=client.headers(),
                    form={'model': 'gpt-4o-mini-transcribe', 'language': 'tr'},
                    files={'file': ('komut.wav', audio, 'audio/wav')}, timeout=90,
                    max_bytes=200_000)
                if stopped.is_set():
                    return ''
                raw_text = result.get('text') if isinstance(result, dict) else None
                text = raw_text.strip() if isinstance(raw_text, str) else ''
                if not text:
                    raise VoiceError('Konuşma anlaşılamadı. Mikrofonu kontrol edip yeniden deneyin.')
                if len(text) > 4000:
                    raise VoiceError('Sesli komut çok uzun. Daha kısa bir komut söyleyin.')
                if self.on_command:
                    self._set_state('working', 'Sesli komut hazırlanıyor. Masaüstü adımları onaya sunulacak.')
                    command = self.on_command(text)
                    if inspect.isawaitable(command):
                        await command
                if not stopped.is_set():
                    self._set_state('idle', 'Sesli komut alındı. Dinleme kapalı.')
                return text
            except asyncio.CancelledError:
                stopped.set()
                self._set_state('idle', 'Dinleme durduruldu.')
                raise
            except Exception as exc:
                self._set_state('error', self._error_message(exc, config))
                raise VoiceError(self._message) from None

    async def speak(self, text: str):
        if not isinstance(text, str) or not text.strip():
            raise VoiceError('Okunacak metin boş.')
        config, stopped = self._begin()
        async with self._operation:
            try:
                self._set_state('working', 'Tok ve sakin erkek sesi hazırlanıyor…')
                client = OpenAIClient(config)
                audio = await client.http.request(
                    'POST', client.base + '/audio/speech', headers=client.headers(),
                    json_body={'model': setting(config, 'openai_tts_model', 'gpt-4o-mini-tts'),
                               'voice': setting(config, 'voice', 'onyx'),
                               'input': text.strip()[:1200], 'speed': 0.95,
                               'response_format': 'wav',
                               'instructions': 'Türkçe konuş. Tok, sakin, yetişkin erkek tonu; '
                                               'doğal, akıcı ve anlaşılır diksiyon. Abartılı robotik ton kullanma.'},
                    raw=True, timeout=90, max_bytes=15_000_000)
                if stopped.is_set():
                    return
                _validate_wav(audio)
                self._set_state('speaking', 'Konuşuyorum. Bu ses yapay zekâ tarafından üretilmiştir.')
                await asyncio.to_thread(self.player.play, audio, stopped)
                if not stopped.is_set():
                    self._set_state('idle', 'Hazır. Dinleme kapalı.')
            except asyncio.CancelledError:
                stopped.set()
                self.player.stop()
                self._set_state('idle', 'Konuşma durduruldu.')
                raise
            except Exception as exc:
                self._set_state('error', self._error_message(exc, config))
                raise VoiceError(self._message) from None

    @staticmethod
    def _error_message(exc, config):
        if isinstance(exc, (VoiceError, ProviderError)):
            message = str(exc)
        else:
            message = 'Ses işlemi tamamlanamadı. Mikrofon, hoparlör ve API bağlantısını kontrol edin.'
        key = setting(config, 'openai_api_key')
        return message.replace(str(key), '[gizli]')[:600] if key else message[:600]
